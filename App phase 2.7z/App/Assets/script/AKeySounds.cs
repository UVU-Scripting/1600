﻿using UnityEngine;
using System.Collections;

public class AKeySounds : MonoBehaviour {

	public AudioSource addSoundEffect;
	
	// Update is called once per frame
	void Update () 
	{
	
		if(Input.GetKeyDown(KeyCode.A)) 
		{
			addSoundEffect.Play();
		}
		if(Input.GetKeyDown(KeyCode.S)) 
		{
		
		}
		if(Input.GetKeyDown(KeyCode.R)) 
		{

		}


	}
}
