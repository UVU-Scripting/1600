﻿using UnityEngine;
using System.Collections;

public class RKeySounds : MonoBehaviour {
	
	public AudioSource resetSoundEffect;
	
	// Update is called once per frame
	void Update () 
	{

		if(Input.GetKeyDown(KeyCode.R)) 
		{
			resetSoundEffect.Play();
		}
			
	}
}