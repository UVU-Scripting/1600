﻿using UnityEngine;
using System.Collections;

public class SKeySounds : MonoBehaviour {
	
	public AudioSource minusSoundEffect;
	
	// Update is called once per frame
	void Update () 
	{
		
		if(Input.GetKeyDown(KeyCode.A)) 
		{

		}
		if(Input.GetKeyDown(KeyCode.S)) 
		{
			minusSoundEffect.Play();
		}
		if(Input.GetKeyDown(KeyCode.R)) 
		{
			
		}
		
		
	}
}