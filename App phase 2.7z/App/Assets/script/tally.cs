﻿using UnityEngine;
using UnityEngine.UI;				//you need this line for the UI text to work
using System.Collections;


public class tally : MonoBehaviour 
{
	public Text countText;
	int tallyInt = 0;
	void Update () 
	{
		if(Input.GetKeyDown(KeyCode.A)) 
		{
			tallyInt ++;
			print(tallyInt);
			SetCountText ();								// this line is part of the public Text countText;
		}
		if(Input.GetKeyDown(KeyCode.S)) 
		{
			if(tallyInt > 0)
			{
				tallyInt --;
				print(tallyInt);
				SetCountText ();							// this line is part of the public Text countText;
			}
			else
			{
				print(tallyInt);
				SetCountText ();							// this line is part of the public Text countText;
			}
		}
		if(Input.GetKeyDown(KeyCode.R)) 
		{
			tallyInt = 0;
			print(tallyInt);
			SetCountText ();								// this line is part of the public Text countText;
		}
	}
	void SetCountText ()
	{
		countText.text = "Score: " + tallyInt.ToString (); // this line is part of the public Text countText;
	}
}
