﻿Thank you for your purchase.

***HD-2D Background Art SUIBOKUGA  Read Me ***

This asset is a high resolution of the background image suitable for 2D platform.

The theme of this asset is "SUIBOKUGA".


== Description ==

-the number of sheets-

 5 sheets

-Image size-

3840x2160px

