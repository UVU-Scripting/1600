﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class appTest : MonoBehaviour 
{
	private int count;
	public Text countText;
	public AudioSource goingUp;
	public AudioSource downSound;
	public AudioSource doOver;
	


	// Use this for initialization
	void Awake () 
	{
		count = 0;
		countText.text = "Count: " + count.ToString ();
	}

	int tallyInt = 0;
	// Update is called once per frame
	void Update () 
	{

		{
			
			if (Input.GetKeyDown (KeyCode.A)) {
				goingUp.Play ();
				tallyInt ++;
				print (tallyInt);
				count = count + 1;
				countText.text = "Count: " + count.ToString ();

			}

			if (Input.GetKeyDown (KeyCode.S)) {
				if (tallyInt >0)
				{ 
				tallyInt --;
				Debug.Log (tallyInt);
					count = count - 1;
					countText.text = "Count: " + count.ToString ();
					downSound.Play();
				}
				else
				{
					Debug.Log (tallyInt);
				}
			}

			if (Input.GetKeyDown (KeyCode.R)) {
				tallyInt = 0;
				print (tallyInt);
				count = 0;
				countText.text = "Count: " + count.ToString ();
				doOver.Play ();
			}
		}
	
	}
}
