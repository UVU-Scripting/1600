﻿using UnityEngine;
using System.Collections;

public class Tallyapppart1 : MonoBehaviour {
	//Vincent Liddiards tally app
	// Use this for initialization
	void Start () {
		//Greet the user and explain function
		print ("this is the tally app! press 'a' for + And 's' for -") ;
		//create variable for tally
		int tallyint = 0;
		//create if statements for inputs
		bool up = Input.GetKeyDown(KeyCode.A);
		bool down = Input.GetKeyDown(KeyCode.S);
		bool reset = Input.GetKeyDown(KeyCode.R);
		if (up)
		{
			tallyint++;
			print(tallyint);
		}
		else if (down)
		{
			
			tallyint--;
			print(tallyint);
		}
		else if (reset)
		{
			tallyint = 0;
			print(tallyint);
		}
		
		
	}
	
	
}


