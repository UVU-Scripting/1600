﻿using UnityEngine;
using System.Collections;

public class tallyApp : MonoBehaviour {

	public int tallyInt = 0;
	void Update () {
		
		
		//Creating a Key Down designator for Incramenting input.getkeydown(keycode.UpArrow);
		if (Input.GetKeyDown (KeyCode.A))
		{
			tallyInt ++;
			print (tallyInt);
		}
		//Creating a Key Down Designatior for Decramanting
		
		if (Input.GetKeyDown (KeyCode.S) && tallyInt > 0)
		{
			tallyInt--;
			print (tallyInt);
			
		}
		//Creating a Key Down Designatior for reset to 0
		if (Input.GetKeyDown (KeyCode.R))
		{
			tallyInt = 0;
			print (tallyInt); 
		}
		
	}
	
	
	
	
	
}
