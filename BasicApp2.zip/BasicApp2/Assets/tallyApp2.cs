﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class tallyApp2 : MonoBehaviour {
	public Text CountText;
	public int tallyInt = 0;
	AudioSource buttonaudio;
	public AudioClip buttonPress;
	public AudioClip resetButton;

	void Start()
	{
		buttonaudio = GetComponent<AudioSource> ();
	}
	void OnGUI () 
	{
		
		
		//Creating a Key Down designator for Incramenting input.getkeydown(keycode.UpArrow);
	 if (GUI.Button(new Rect(75, 300, 50, 50), "+"))
		{
			tallyInt ++;
			print (tallyInt);
			CountText.text = "Count: " +tallyInt.ToString();

			buttonaudio.PlayOneShot(buttonPress, 10);
			
		}
		//Creating a Key Down Designatior for Decramanting
		
	 if (GUI.Button(new Rect(175, 300, 50, 50), "-") && tallyInt > 0)
		{
			tallyInt--;
			print (tallyInt);
			CountText.text = "Count: " +tallyInt.ToString();
			buttonaudio.PlayOneShot(buttonPress, 10);
			}
		//Creating a Key Down Designatior for reset to 0
	 if (GUI.Button(new Rect(275, 300, 50, 50), "R"))
		    {
			tallyInt = 0;
			print (tallyInt); 
			CountText.text = "Count: " +tallyInt.ToString();
			buttonaudio.PlayOneShot(resetButton, 10);
		
			
		}
	
	}

}
