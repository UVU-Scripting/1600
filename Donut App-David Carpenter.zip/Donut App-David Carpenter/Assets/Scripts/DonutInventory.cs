﻿using UnityEngine;
using System.Collections;

public class DonutInventory : MonoBehaviour {
	

	// Update is called once per frame
	void Update () {


	
	}
}
