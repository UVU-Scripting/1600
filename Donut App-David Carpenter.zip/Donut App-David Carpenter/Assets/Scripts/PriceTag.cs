﻿using UnityEngine;
using System.Collections;

public class PriceTag : MonoBehaviour {

	public float price;

}
