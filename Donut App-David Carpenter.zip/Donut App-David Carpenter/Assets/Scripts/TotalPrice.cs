﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TotalPrice : MonoBehaviour {

	public Text price;
	public Text pickup;
	public Text delivery;
	public Text totalprice;

	public float priceNumber;
	public float tax;
	public float deliveryPrice;
	public float totalPrice;

	
	// Use this for initialization
	void Start () {
		priceNumber = 0;
		tax = 0;
		deliveryPrice = 0;

		price = price.GetComponent<Text> ();
		pickup = pickup.GetComponent<Text> ();
		delivery = delivery.GetComponent<Text> ();
		totalprice = totalprice.GetComponent<Text> ();
	}

	public void Calculate (float x) 
	{
		tax = x * 0.25f;
		deliveryPrice = x * 0.99f;
		totalPrice = x * tax * deliveryPrice;
	}
	// Update is called once per frame
	void Update () {

	
	}
}
