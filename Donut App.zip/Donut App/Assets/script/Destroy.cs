﻿using UnityEngine;
using System.Collections;

public class Destroy : MonoBehaviour {
	private Rigidbody rBody;
	// Use this for initialization
	void Start () 
	{
		rBody = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter (Collision other)
	{	
		if (other.gameObject.CompareTag ("original")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("chocolate")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("maple")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("sugar")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("sprinkle")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("powdered")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("chocolatecake")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("cinnamon")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("kreme")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("originalhole")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("chocolatehole")) 
		{
			Destroy (other.gameObject);
		}
		if (other.gameObject.CompareTag ("cruller")) 
		{
			Destroy (other.gameObject);
		}
	}
}
