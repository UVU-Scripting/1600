﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class inventory : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
