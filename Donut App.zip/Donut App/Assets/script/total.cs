﻿using UnityEngine;
using UnityEngine.UI;				//you need this line for the UI text to work
using System.Collections;

public class total : MonoBehaviour {
	private Rigidbody rBody;
	float OriginalTallyInt = 0.00f;
	float ChocolateTallyInt = 0.00f; 
	float MapleTallyInt = 0.00f;
	float SugarTallyInt = 0.00f;
	float SprinkleTallyInt = 0.00f;
	float PowderedTallyInt = 0.00f;
	float ChocolatecakeTallyInt = 0.00f;
	float CinnamonTallyInt = 0.00f;
	float KremeTallyInt = 0.00f;
	float OriginalholeTallyInt = 0.00f;
	float ChocolateholeTallyInt = 0.00f;
	float CrullerTallyInt = 0.00f;

	float DonutsSubTotal = 0.00f;

	float DonutsTax = 0.00f;

	float DeliveryCost = 0.00f;

	float DonutsTotal = 0.00f;

	public Text OriginalCountText;
	public Text ChocolateCountText;
	public Text MapleCountText;
	public Text SugarCountText;
	public Text SprinkleCountText; 
	public Text PowderedCountText;
	public Text ChocolatecakeCountText;
	public Text CinnamonCountText;
	public Text	KremeCountText;
	public Text OriginalholeCountText;
	public Text	ChocolateholeCountText;
	public Text	CrullerCountText;

	public Text DonutsSubTotalText;

	public Text DonutsTaxText; 

	public Text DeliveryCostText;

	public Text DonutsTotalText;
	

	void start ()
	{
		rBody = GetComponent<Rigidbody> ();
	}
	void OnCollisionEnter (Collision other)
	{	
		if (other.gameObject.CompareTag ("original")) 
		{

			if (OriginalTallyInt >= 10.88f) 
			{
				OriginalTallyInt = 7.99f;
				print ("1 Glazed dozen bonus!");
				OriginalSetCountText ();
			} 
			else 
			{
				OriginalTallyInt += 0.99f;
				print (OriginalTallyInt);
				OriginalSetCountText ();
			}
		}
		/*
		if (other.gameObject.CompareTag ("original")) 
		{	
			OriginalTallyInt  += 0.99f;
			print (OriginalTallyInt);
			OriginalSetCountText ();								// this line is part of the public Text countText;
		}
		*/
		if (other.gameObject.CompareTag ("chocolate")) 
		{
			ChocolateTallyInt  += 1.09f;
			print (ChocolateTallyInt);
			ChocolateSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("maple")) 
		{
			MapleTallyInt  += 1.09f;
			print (ChocolateTallyInt);
			MapleSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("sugar")) 
		{
			SugarTallyInt  += 1.09f;
			print (SugarTallyInt);
			SugarSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("sprinkle")) 
		{
			SprinkleTallyInt  += 1.09f;
			print (SprinkleTallyInt);
			SprinkleSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("powdered")) 
		{
			PowderedTallyInt  += 1.09f;
			print (PowderedTallyInt);
			PowderedSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("chocolatecake")) 
		{
			ChocolatecakeTallyInt  += 1.09f;
			print (ChocolatecakeTallyInt);
			ChocolatecakeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("cinnamon")) 
		{
			CinnamonTallyInt  += 1.09f;
			print (CinnamonTallyInt);
			CinnamonSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("kreme")) 
		{
			KremeTallyInt  += 1.09f;
			print (KremeTallyInt);
			KremeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("originalhole")) 
		{
			OriginalholeTallyInt  += 0.49f;
			print (OriginalholeTallyInt);
			OriginalholeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("chocolatehole")) 
		{
			ChocolateholeTallyInt  += 0.49f;
			print (ChocolateholeTallyInt);
			chocolateholeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("cruller")) 
		{
			CrullerTallyInt  += 0.49f;
			print (CrullerTallyInt);
			CrullerSetCountText ();								// this line is part of the public Text countText;
		}
	}








	void OnCollisionExit (Collision other)
	{
		if (other.gameObject.CompareTag("original"))
		{
			OriginalTallyInt -= 0.99f;
			print(OriginalTallyInt);
			OriginalSetCountText ();							// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag("chocolate"))
		{
			ChocolateTallyInt -= 1.09f;
			print(ChocolateTallyInt);
			ChocolateSetCountText ();							// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag("maple"))
		{
			MapleTallyInt -= 1.09f;
			print(ChocolateTallyInt);
			MapleSetCountText ();							// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag("sugar"))
		{
			SugarTallyInt -= 1.09f;
			print(SugarTallyInt);
			SugarSetCountText ();							// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag("sprinkle")) 
		{
			SprinkleTallyInt  -= 1.09f;
			print (SprinkleTallyInt);
			SprinkleSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("powdered")) 
		{
			PowderedTallyInt  -= 1.09f;
			print (PowderedTallyInt);
			PowderedSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("chocolatecake")) 
		{
			ChocolatecakeTallyInt  -= 1.09f;
			print (ChocolatecakeTallyInt);
			ChocolatecakeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("cinnamon")) {
			CinnamonTallyInt  -= 1.09f;
			print (CinnamonTallyInt);
			CinnamonSetCountText ();
		}
		if (other.gameObject.CompareTag ("kreme")) 
		{
			KremeTallyInt  -= 1.09f;
			print (KremeTallyInt);
			KremeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("originalhole")) 
		{
			OriginalholeTallyInt  -= 0.49f;
			print (OriginalholeTallyInt);
			OriginalholeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("chocolatehole")) 
		{
			ChocolateholeTallyInt  -= 0.49f;
			print (ChocolateholeTallyInt);
			chocolateholeSetCountText ();								// this line is part of the public Text countText;
		}
		if (other.gameObject.CompareTag ("cruller")) 
		{
			CrullerTallyInt  -= 0.49f;
			print (CrullerTallyInt);
			CrullerSetCountText ();								// this line is part of the public Text countText;
		}
	}


	void OriginalSetCountText ()
	{
		OriginalCountText.text = "Original Glazed: $" + OriginalTallyInt.ToString ("F2"); // this line is part of the public Text countText;
	}
	void ChocolateSetCountText ()
	{
		ChocolateCountText.text = "Chocolate: $" + ChocolateTallyInt.ToString ("F2");
	}
	void MapleSetCountText ()
	{
		MapleCountText.text = "Maple: $" + MapleTallyInt.ToString ("F2");
	}
	void SugarSetCountText ()
	{
		SugarCountText.text = "Sugar: $" + SugarTallyInt.ToString ("F2");
	}
	void SprinkleSetCountText ()
	{
		SprinkleCountText.text = "Sprinkle: $" + SprinkleTallyInt.ToString ("F2");
	}
	void PowderedSetCountText ()
	{
		PowderedCountText.text = "Powdered: $" + PowderedTallyInt.ToString ("F2");
	}
	void ChocolatecakeSetCountText ()
	{
		ChocolatecakeCountText.text = "Chocolate Cake: $" + ChocolatecakeTallyInt.ToString ("F2");
	}
	void CinnamonSetCountText ()
	{
		CinnamonCountText.text = "Cinnamon: $" + CinnamonTallyInt.ToString ("F2");
	}
	void KremeSetCountText ()
	{
		KremeCountText.text = "Kreme: $" + KremeTallyInt.ToString ("F2");
	}
	void OriginalholeSetCountText ()
	{
		OriginalholeCountText.text = "Original Hole: $" + OriginalholeTallyInt.ToString ("F2");
	}
	void chocolateholeSetCountText ()
	{
		ChocolateholeCountText.text = "Chocolate Hole: $" + ChocolateholeTallyInt.ToString ("F2");
	}
	void CrullerSetCountText ()
	{
		CrullerCountText.text = "Mini Cruller: $" + CrullerTallyInt.ToString ("F2");
	}
	void DonutsSubTotalSetCount ()
	{
		DonutsSubTotalText.text = "Sub-Total: $" + DonutsSubTotal.ToString ("F2");
	}
	void DonutsTaxSetCount ()
	{
		DonutsTaxText.text = "Tax: $" + DonutsTax.ToString ("F2"); 
	}
	void DonutsTotalSetCount ()
	{
		DonutsTotalText.text = "Total: $ " + DonutsTotal.ToString ("F2");
	}
	void DeliveryCostSetCount ()
	{
		DeliveryCostText.text = "Delivery Cost: $" + DeliveryCost.ToString ("F2");
	}
	void Update()
	{
		{
			DonutsSubTotal = OriginalTallyInt + ChocolateTallyInt + MapleTallyInt + SugarTallyInt + SprinkleTallyInt + PowderedTallyInt + ChocolatecakeTallyInt + CinnamonTallyInt + KremeTallyInt + OriginalholeTallyInt + ChocolateholeTallyInt + CrullerTallyInt;
			DonutsSubTotalSetCount ();
		}
		{
			DonutsTax = DonutsSubTotal * .0795f;
			DonutsTaxSetCount ();
		}
		{	
			DonutsTotal = DonutsTax + DonutsSubTotal + DeliveryCost;
			DonutsTotalSetCount ();
		}
	}
	void DeliveryButton ()
	{
		DeliveryCost = 10.00f;
		DeliveryCostSetCount ();
		Debug.Log ("Delivery Cost");
		
	}
	void PickUPButton ()
	{
		DeliveryCost = 0.00f;
		DeliveryCostSetCount ();
		Debug.Log ("Delivery Cost");
		
	}
}
