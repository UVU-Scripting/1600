﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class Draggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler  {

	public void OnBeginDrag(PointerEventData eventdata){
		Debug.Log ("OnBeginDrag");

	}

	public void OnDrag(PointerEventData eventdata){
		Debug.Log ("OnDrag");
		this.transform.position = eventdata.position;
	}

	public void OnEndDrag(PointerEventData eventdata){
		Debug.Log ("OnEndDrag");
	}

}
