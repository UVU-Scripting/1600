﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class systemUI : MonoBehaviour {
	//Preset Donuts With Prices
	//Don't forget Sales Tax
	//Number of Donuts
	//Company Name, logo, location
	//pick-up/delivery
	//custom toppings
	//custom filling
	//sprinkles
	//frosting
	string sTime;
	public Button newOrder;
	bool newOrderBool = false;
	public GameObject newOrderMenu;
	public GameObject newOrderPreMenu;
	public Button closeNewOrder;
	bool newOrderCloseBool = false;
	public GameObject newOrderMenuClose;
	public Button cancelOrder;
	public Button cancelOrderPromptGoBack;
	//new order menus
	//menu1Name input
	public GameObject nOM1;
	public Button nOM1Next;
	bool nOM1Bool = true;
	string nameFirst;
	string nameLast;
	public Button nOM1Custom;
	public Text nameInputError;
	string phoneNumber;
	string phoneNumber1;
	string phoneNumber2;
	int phoneNumberint;
	int phoneNumberint1;
	int phoneNumberint2;
	//menu2Items	
	public GameObject nOM2;
	public Button nOM2Next;
	public Button nOM2Back;
	bool nOM2Bool = false;
	//menu3DeliveryInquiry
	public GameObject nOM3;
	public Button nOM3Back;
	public Button nOM3Delivery;
	public Button nOM3PickUp;
	bool nOM3Bool = false;
	//menu4Delivery
	public GameObject nOM4D;
	public Button nOM4DBack;
	public Button nOM4DNext;
	public string aAddress;
	public string aCity;
	public string aState;
	public string aZip;
	public Text addressError;
	bool nOM4DBool = false;
	//menu4PickUp
	public GameObject nOM4;
	public Button nOM4Next;
	public Button nOM4Back;
	public Text nOM4Name;
	public Text nOM4Number;
	bool nOM4Bool = false;
	//menu5Delivery
	public GameObject nOM5D;
	public Button nOM5DBack;
	public Button nOM5DNext;
	public Text nOM5DNameCheck;
	public Text nOM5DAddressCheck;
	public Text nOM5DNumberCheck;
	bool nOM5DBool = false;
	//menu6Pay
	public GameObject nOM6D;
	public Button nOM6DBack;
	public Button nOM6DPayAndFinish;
	public string cCN;
	public string cCN1;
	public string cCN2;
	public string cCN3;
	public int cCNint;
	public int cCNint1;
	public int cCNint2;
	public int cCNint3;
	public string cCExpMM;
	public int cCExpMMint;
	public string cCExpYY;
	public int cCExpYYint;
	public string cCCVV;
	public int cCCVVint;
	public Text cCErrorText;
	bool nOM6DBool = false;
	//menu7End
	public GameObject nOM7D;
	public float nOM7Timer = 10f;
	bool nOM7DBool = false;
	//menu2d1Custom
	bool nOM2d1Bool = false;
	public GameObject nOM2d1;
	public Button nOM2d1Back;
	public Button nOM2d1Next;
	//menu3d1Build
	public GameObject nOM3d1;
	bool nOM3d1Bool = false;
	//glazed
		public Button nOM2GlazedAdd;
		public Button nOM2GlazedSubtract;
		public Text nOM2GlazedNumber;
		int nOM2GlazedInt = 0;
		float glazedPrice = .5f;
	//maple
		public Button nOM2MapleAdd;
		public Button nOM2MapleSubtract;
		public Text nOM2MapleNumber;
		int nOM2MapleInt = 0;
		float maplePrice = .65f;
	//totals
		float subTotal;
	    int deliveryFee;
		public Text grandTotalText;
		public Text taxTotalText;
		public Text subTotalText;
		float taxTotal;
		float grandTotal;



	void Start () {
		newOrder.onClick.AddListener (() => NewOrder ());
		closeNewOrder.onClick.AddListener (() => CloseNewOrder ());
		cancelOrder.onClick.AddListener (() => CancelOrder ());
		cancelOrderPromptGoBack.onClick.AddListener (() => CloseNewOrder ());
		//menu1 Buttons
		nOM1Next.onClick.AddListener (() => NOM1Next ());
		nOM1Custom.onClick.AddListener (() => NOM1Custom ());
		//menu2 Buttons
		nOM2Back.onClick.AddListener (() => NOM2Back ());
		nOM2Next.onClick.AddListener (() => NOM2Next ());
		nOM2GlazedAdd.onClick.AddListener (() => NOM2GlazedAdd ());
		nOM2GlazedSubtract.onClick.AddListener (() => NOM2GlazedSubtract ());
		nOM2MapleAdd.onClick.AddListener (() => NOM2MapleAdd ());
		nOM2MapleSubtract.onClick.AddListener (() => NOM2MapleSubtract ());
		//menu3 Buttons
		nOM3Back.onClick.AddListener (() => NOM2Next ());
		nOM3Delivery.onClick.AddListener (() => NOM3Delivery ());
		nOM3PickUp.onClick.AddListener (() => NOM3PickUp ());
		//menu4Pickup Buttons
		nOM4Back.onClick.AddListener (() => NOM3PickUp ());
		nOM4Next.onClick.AddListener (() => NOM4Next ());
		//menu4Delivery Buttons
		nOM4DBack.onClick.AddListener (() => NOM3Delivery ());
		nOM4DNext.onClick.AddListener (() => NOM4DNext ());
		//menu5Delivery Buttons
		nOM5DBack.onClick.AddListener (() => NOM5DBack ());
		nOM5DNext.onClick.AddListener (() => NOM5DNext ());
		//menu6Pay Buttons
		nOM6DBack.onClick.AddListener (() => NOM6DBack ());
		nOM6DPayAndFinish.onClick.AddListener (() => NOM6DPayAndFinish ());
		//menu2d1 Buttons
		nOM2d1Back.onClick.AddListener (() => NOM2d1Back ());
		nOM2d1Next.onClick.AddListener (() => NOM2d1Next ());
	}
	void Update () {
		//active windows
		newOrderMenu.SetActive (newOrderBool);
		newOrderPreMenu.SetActive (!newOrderBool);
		newOrderMenuClose.SetActive (newOrderCloseBool);
		nOM1.SetActive (nOM1Bool);
		nOM2.SetActive (nOM2Bool);
		nOM2d1.SetActive (nOM2d1Bool);
		nOM3d1.SetActive (nOM3d1Bool);
		nOM3.SetActive (nOM3Bool);
		nOM4D.SetActive (nOM4DBool);
		nOM4.SetActive (nOM4Bool);
		nOM5D.SetActive (nOM5DBool);
		nOM6D.SetActive (nOM6DBool);
		nOM7D.SetActive (nOM7DBool);
		if (nOM7DBool == true) {
			nOM7Timer -= Time.deltaTime;
		}
		if (nOM7DBool == false) {
			nOM7Timer = 10f;
		}
		if (nOM7Timer < 0) {
			nOM4Bool = false;
			nOM7DBool = false;
			nOM1Bool = true;
			newOrderBool = !newOrderBool;

		}
		//price calculation
		subTotal = ((nOM2GlazedInt * glazedPrice) + (nOM2MapleInt * maplePrice));
		subTotalText.text = subTotal.ToString ("c2");
		taxTotal = (.047f * subTotal);
		taxTotalText.text = taxTotal.ToString ("c2");
		grandTotal = ((1.047f * subTotal) + deliveryFee);
		grandTotalText.text = grandTotal.ToString("c2");

	}
	void NewOrder () {
		newOrderBool = !newOrderBool;
	}
	void CloseNewOrder () {
		newOrderCloseBool = !newOrderCloseBool;
	}
	void CancelOrder () {
		newOrderBool = !newOrderBool;
		newOrderCloseBool = !newOrderCloseBool;
		nOM1Bool = true;
		nameInputError.text = "";
		nOM2Bool = false;
		nOM3Bool = false;
		nOM4DBool = false;
		nOM4Bool = false;
		addressError.text = "";
		nOM5DBool = false;
		nOM6DBool = false;
		nOM7DBool = false;
		nOM2d1Bool = false;
		nOM3d1Bool = false;
		nOM2GlazedInt = 0;
		nOM2MapleInt = 0;
		deliveryFee = 0;
	}
	void NOM1Next () {
		nameFirst = GameObject.Find("nameInputFirstText").GetComponents<Text> () [0].text;
		nameLast = GameObject.Find("nameInputLastText").GetComponents<Text> () [0].text;
		phoneNumber = GameObject.Find("phoneNumberInputFieldText").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber, out phoneNumberint);
		phoneNumber1 = GameObject.Find("phoneNumberInputFieldText1").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber1, out phoneNumberint1);
		phoneNumber2 = GameObject.Find("phoneNumberInputFieldText2").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber2, out phoneNumberint2);

		if ((nameLast == "") || (nameFirst == "") || phoneNumber.Length < 3 || phoneNumber1.Length < 3 || phoneNumber2.Length < 4) {
			nameInputError.text = "Oops! We'll need your whole name and a valid number!";
		} 
		else {
			nOM1Bool = !nOM1Bool;
			nOM2Bool = !nOM2Bool;
			nameInputError.text = "";
			nOM5DNameCheck.text = nameFirst + " " + nameLast;
			nOM5DNumberCheck.text = phoneNumber + "-" + phoneNumber1 + "-" + phoneNumber2;
		}
	}
	void NOM1Custom () {
		nameFirst = GameObject.Find("nameInputFirstText").GetComponents<Text> () [0].text;
		nameLast = GameObject.Find("nameInputLastText").GetComponents<Text> () [0].text;
		phoneNumber = GameObject.Find("phoneNumberInputFieldText").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber, out phoneNumberint);
		phoneNumber1 = GameObject.Find("phoneNumberInputFieldText1").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber1, out phoneNumberint1);
		phoneNumber2 = GameObject.Find("phoneNumberInputFieldText2").GetComponents<Text> ()[0].text;
		int.TryParse (phoneNumber2, out phoneNumberint2);
		if ((nameLast == "") || (nameFirst == "") || phoneNumber.Length < 3 || phoneNumber1.Length < 3 || phoneNumber2.Length < 4) {
			nameInputError.text = "Oops! We'll need your whole name and a valid number!";
		} else {
			nOM2d1Bool = !nOM2d1Bool;
			nOM1Bool = !nOM1Bool;
			nameInputError.text = "";
		}
	}
	void NOM2Back () {
		nOM1Bool = !nOM1Bool;
		nOM2Bool = !nOM2Bool;
	}
	void NOM2Next () {
		nOM2Bool = !nOM2Bool;
		nOM3Bool = !nOM3Bool;
	}
	void NOM2GlazedAdd () {
		nOM2GlazedInt++;
		nOM2GlazedNumber.text = "" + nOM2GlazedInt;
	}
	void NOM2GlazedSubtract () {
		if (nOM2GlazedInt > 0) {
		nOM2GlazedInt--;
		nOM2GlazedNumber.text = "" + nOM2GlazedInt;
		}
	}
	void NOM2MapleAdd () {
		nOM2MapleInt++;
		nOM2MapleNumber.text = "" + nOM2MapleInt;
	}
	void NOM2MapleSubtract () {
		if (nOM2MapleInt > 0) {
			nOM2MapleInt--;
			nOM2MapleNumber.text = "" + nOM2MapleInt;
		}
	}
	void NOM3Delivery () {
		nOM3Bool = !nOM3Bool;
		nOM4DBool = !nOM4DBool;
		addressError.text = "";
	}
	void NOM3PickUp () {
		nOM3Bool = !nOM3Bool;
		nOM4Bool = !nOM4Bool;
		nOM4Name.text = nameFirst + " " + nameLast;
		nOM4Number.text = phoneNumber + "-" + phoneNumber1 + "-" + phoneNumber2;
		}
	void NOM4DNext () {
		aAddress = GameObject.Find("nOM3DIFAddressText").GetComponents<Text> () [0].text;
		aCity = GameObject.Find("nOM3DIFCityText").GetComponents<Text> () [0].text;
		aState = GameObject.Find("nOM3DIFStateText").GetComponents<Text> () [0].text;
		aZip = GameObject.Find("nOM3DIFZipText").GetComponents<Text> () [0].text;
		if (((aAddress) == "") || ((aCity) == "") || ((aState) == "") || ((aZip) == "")) {
			addressError.text = "Oops! We'll need your full address!";
		}
		else {
			nOM4DBool = !nOM4DBool;
			nOM5DBool = !nOM5DBool;
			deliveryFee = 3;
			nOM5DAddressCheck.text = aAddress + " " + aCity + " " + aState + ", " + aZip;
		}
	}
	void NOM4Next () {
		nOM4Bool = !nOM4Bool;
		nOM7DBool = !nOM7DBool;
	}
	void NOM5DBack () {
		nOM4DBool = !nOM4DBool;
		nOM5DBool = !nOM5DBool;
		deliveryFee = 0;
	}
	void NOM5DNext () {
		nOM5DBool = !nOM5DBool;
		nOM6DBool = !nOM6DBool;
	}
	void NOM6DBack () {
		nOM5DBool = !nOM5DBool;
		nOM6DBool = !nOM6DBool;
		cCErrorText.text = "";
	}
	void NOM6DPayAndFinish () {
		cCN = GameObject.Find("nOM6CardNumberText").GetComponents<Text> ()[0].text;
		int.TryParse (cCN, out cCNint);
		cCN1 = GameObject.Find("nOM6CardNumberText").GetComponents<Text> ()[0].text;
		int.TryParse (cCN, out cCNint1);
		cCN2 = GameObject.Find("nOM6CardNumberText").GetComponents<Text> ()[0].text;
		int.TryParse (cCN, out cCNint2);
		cCN3 = GameObject.Find("nOM6CardNumberText").GetComponents<Text> ()[0].text;
		int.TryParse (cCN, out cCNint3);
		cCExpMM = GameObject.Find("nOM6CardExpMMText").GetComponents<Text> ()[0].text;
		int.TryParse (cCExpMM, out cCExpMMint);
		cCExpYY = GameObject.Find("nOM6CardExpYYText").GetComponents<Text> ()[0].text;
		int.TryParse (cCExpYY, out cCExpYYint);
		cCCVV = GameObject.Find("nOM6CardCVVText").GetComponents<Text> ()[0].text;
		int.TryParse (cCCVV, out cCCVVint);
		if (((cCNint > 299 && cCNint < 400) || (cCNint > 3999 && cCNint < 6999)) && cCNint1 > 1 && cCNint1 < 10000 
		    && cCN1.Length == 4 && cCNint2 > 0 && cCNint2 < 10000 && cCN2.Length == 4 && cCNint3 > 0 && cCNint3 < 10000 
		    && cCN3.Length == 4 && cCExpMMint > 0 && cCExpMMint < 13 && cCExpYYint > 0 && cCExpYY.Length < 4 
		    && cCExpYY.Length > 1 && cCCVV.Length == 3) {
			nOM6DBool = !nOM6DBool;
			nOM7DBool = !nOM7DBool;

		} else {
			cCErrorText.text = "Please enter valid and complete card information.";
		}
	}
	void NOM2d1Next () {

			nOM2d1Bool = !nOM2d1Bool;
			nOM3d1Bool = !nOM3d1Bool;
	}
	void NOM2d1Back () {
		nOM2d1Bool = !nOM2d1Bool;
		nOM1Bool = !nOM1Bool;
		nameInputError.text = "";
	}
}
