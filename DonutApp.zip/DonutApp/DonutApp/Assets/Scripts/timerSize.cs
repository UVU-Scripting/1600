﻿using UnityEngine;
using System.Collections;

public class timerSize : MonoBehaviour {
	public GameObject systemUIGO;
	private systemUI SystemUIVars;
	void Awake () {
		SystemUIVars = systemUIGO.GetComponent<systemUI> ();
	}
	void Update () {
		if (SystemUIVars.nOM7Timer < 10f) {
			transform.localScale -= new Vector3 (.001666f, 0f, 0f);
		}
		if (SystemUIVars.nOM7Timer == 10f) {
			transform.localScale = new Vector3 (1, 1, 1);
		}
	}
}
