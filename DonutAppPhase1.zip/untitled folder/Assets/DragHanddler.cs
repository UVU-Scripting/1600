﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class DragHanddler : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler {
	public static GameObject itemBeingDragged;

	Vector3 startPosition;
	Transform startParent;



	public void OnDrag (PointerEventData eventData)
	{
		transform.position = Input.mousePosition;

	}



	public void OnBeginDrag (PointerEventData eventData)
	{

		itemBeingDragged = gameObject;
		startPosition = transform.position;
		startParent = transform.parent;

		PrefabSrcipt.Instance.Donut = itemBeingDragged;
		GameObject Clone = Instantiate(PrefabSrcipt.Instance.Donut);
		Clone.transform.parent = startParent;
		GetComponent<CanvasGroup> ().blocksRaycasts = false;
		Clone.name = itemBeingDragged.name;

	}



	public void OnEndDrag (PointerEventData eventData)
	{	
		itemBeingDragged = null;
		GetComponent<CanvasGroup> ().blocksRaycasts = true;

		
		
		if (transform.parent == startParent) {
			transform.position = startPosition;
		}

		 	
	
	}





}
