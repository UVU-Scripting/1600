﻿using UnityEngine;
using System.Collections;

public class PrefabSrcipt : MonoBehaviour 
{
	// Assign the prefab in the inspector
	public GameObject Donut;
	//Singleton
	private static PrefabSrcipt m_Instance = null;
	public static PrefabSrcipt Instance
	{
		get
		{
			if (m_Instance == null)
			{
				m_Instance = (PrefabSrcipt)FindObjectOfType(typeof(PrefabSrcipt));
			}
			return m_Instance;
		}
	}
}
