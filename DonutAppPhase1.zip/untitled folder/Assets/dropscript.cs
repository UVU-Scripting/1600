﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class dropscript : MonoBehaviour, IDropHandler {
	public Text totaltext;
	public int maxCount = 0;
	public float donutPrice = 1.99f;
	public float donutPriceTwo = 1.99f;
	public float total = 1.99f;
	public float newTotal;
	public GameObject[] incramentTag;

	public void Update()
	{

		incramentTag = GameObject.FindGameObjectsWithTag("Respawn");
	}

		public  GameObject item {
		get {
			if(transform.childCount>0){
				return transform.GetChild (0).gameObject;
			}
			return null;
		}


	}
	
	
	public void OnDrop (PointerEventData eventData)
	{

		if (!item) {
			DragHanddler.itemBeingDragged.transform.SetParent (transform);
			if (gameObject.tag == "Slot" || gameObject.tag == "Background" || gameObject.tag == "DonutBox") {
				Destroy(DragHanddler.itemBeingDragged);
				//Debug.Log(DragHanddler.itemBeingDragged +"has been destroyed");
			}
			
		} 
		if (DragHanddler.itemBeingDragged) {
		 while (incramentTag != null){
		
			 
				
				
				total += 1.99f;
				totaltext.text = "Total: " + total.ToString ();
				
			}

			Debug.Log (total);
		}
		
		Debug.Log (DragHanddler.itemBeingDragged + "has been dropped");


	}

	}




