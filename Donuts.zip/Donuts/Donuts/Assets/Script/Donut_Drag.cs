﻿using UnityEngine;
using System.Collections;

public class Donut_Drag : MonoBehaviour {


	const string DONUT = "Donut";

	bool hit_Test;
	Ray ray;
	RaycastHit hit;
	GameObject current_Donut;

	void Start(){
		hit_Test = false;
	}
	
	void Update () {
		if (Input.GetMouseButtonDown (0) && hit_Test == false)
			Drag ();
		else if (Input.GetMouseButtonUp (0) && hit_Test == true) {
			hit_Test = false;
			current_Donut.GetComponent<Donuts> ().follow = false;
		}
	}

	void Drag () {
		ray = Camera.main.ScreenPointToRay(Input.mousePosition);

		if (Physics.Raycast (ray, out hit)) {
			if (hit.transform.tag == DONUT){
				hit_Test = true;
				current_Donut = hit.collider.gameObject;
				current_Donut.GetComponent<Donuts>().follow = true;
			}
		}
	}
}
