﻿using UnityEngine;
using System.Collections;

public class Donuts : MonoBehaviour {
    const string BOX = "Box_Trigger", RESET = "Reset_Trigger", TRASH = "Trash_Trigger", DONUT = "Donut";
	const float TWO = 2.0f, Z_POSITION = 8.0f, Z_POSITION_DROPPED = 12.0f;
    public float cost;
	public bool follow, first_Snap;
    private bool dropped, snap, reset, collision, first_Collision_Check, collision_Check, trash;
	Vector3 new_Position, original_Position, p_Original_Position;
    GameObject donut_Clone;

	// Use this for initialization
	void Start(){
        original_Position = transform.position;
		follow = false;
        dropped = true;
        snap = false;
        trash = false;
        collision = false;
        first_Snap = false;
        reset = false;
        first_Collision_Check = false;
        collision_Check = false;
	}

	void Update(){
		Follow (follow);
	}

	void Follow(bool x){
		if (x == true) {
            dropped = false;
			new_Position = new Vector3 (Input.mousePosition.x, Input.mousePosition.y, Z_POSITION);
			transform.position = Camera.main.ScreenToWorldPoint(new_Position);
		}
        else if(x == false && dropped == false){
            dropped = true;
            new_Position = new Vector3(Input.mousePosition.x, Input.mousePosition.y, Z_POSITION_DROPPED);
            transform.position = Camera.main.ScreenToWorldPoint(new_Position);
        }
        else if(x == false && dropped == true) {
            Collision();
            Snap();
            Trash();
            Reset();
        }
	}

    void Snap() {
        if (snap == true)
        {
            if (first_Snap == false)
            {
                first_Collision_Check = true;
                first_Snap = true;
                Instantiate(gameObject, original_Position, Quaternion.identity);
            }
            snap = false;
            reset = false;
            collision_Check = true;
            transform.localPosition = new Vector3(Mathf.Round(transform.position.x), Mathf.Round(transform.position.y), transform.position.z - TWO);
        }
    }

    void Trash() {
        if (trash == true && first_Snap == true)
        {
            trash = false;
            reset = false;
            The_GUI.sub_Total_Cost = The_GUI.sub_Total_Cost - cost;
            Destroy(gameObject);
        }
        else if (trash == true && first_Snap == false)
            trash = false;
    }

    void Reset(){
        if (reset == true){
            collision = false;
            collision_Check = false;
            reset = false;
            transform.position = original_Position;
        }
    }

    void Collision() {
        if (collision == true && first_Collision_Check == true)
            Destroy(gameObject);
        else if (collision == true && first_Collision_Check == false && collision_Check == true)
            reset = true;
        else if (collision == true && first_Collision_Check == false && collision_Check == false)
            collision = false;
        else if (collision == false && first_Collision_Check == true && collision_Check == true){
            The_GUI.sub_Total_Cost = The_GUI.sub_Total_Cost + cost;
            first_Collision_Check = false;
            collision_Check = false;
            original_Position = transform.position;
        }
        else if (collision == false && first_Collision_Check == false && collision_Check == true){
            collision_Check = false;
            original_Position = transform.position;
        }
    }

    void OnCollisionEnter(Collision x) {
        if (x.gameObject.tag == DONUT)
            collision = true;
    }

    void OnTriggerEnter(Collider x){
        if (x.tag == BOX)
            snap = true;
        else if (x.tag == TRASH)
            trash = true;
        else if (x.tag == RESET)
            reset = true;
    }
}
