﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class The_GUI : MonoBehaviour {
    public static float sub_Total_Cost, tax, total_Cost, deliver_Cost;
    const float TAX_MULTI = 0.07f, DELIVER = 2.00f;

    public bool deliver_Check;

    public Text sub_Total, the_Tax, the_Deliver, total;
    public Button deliver_Button;

    // Use this for initialization
    void Start () {
        deliver_Check = false;
        sub_Total_Cost = 0.0f;
        tax = 0.0f;
        total_Cost = 0.0f;
        deliver_Cost = 0.0f;
    }
	
	// Update is called once per frame
	void Update () {
        if (deliver_Check == false)
            deliver_Cost = 0.0f;
        else if (deliver_Check == true)
            deliver_Cost = DELIVER;

        total_Cost = deliver_Cost + tax + sub_Total_Cost;
        tax = (deliver_Cost + sub_Total_Cost) * TAX_MULTI;

        sub_Total.text = string.Format("{0:C}", sub_Total_Cost);
        the_Tax.text = string.Format("{0:C}", tax);
        total.text = string.Format("{0:C}", total_Cost);
        the_Deliver.text = string.Format("{0:C}", deliver_Cost);
    }

    public void Deliver_Check(){
        if (deliver_Check == false){
            deliver_Check = true;
            deliver_Cost = 0.0f;
        }
        else if (deliver_Check == true){
            deliver_Check = false;
            deliver_Cost = DELIVER;
        }
    }
}
