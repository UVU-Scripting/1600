Hello this is the readme file to David Carpenter's Final Game Project
Enjoy!


Controls:
Move- A,S,W,D
Jump- Space
Shoot- Left Mouse Button
Point Around- Move the mouse (honestly, please don't be this stupid)


Changes from original Survival Shooter
- Three health packs in three different locations.
- You can jump..........twice!
- Changed the weapon sound to more of a repeating beam lazer
- Changed score text color
- Changed color of players nightgown
- gave enemies slightly more health and damage and score (Zombear and Hellephant).
- changed background music to Extreme Action by bensound (wanted something more royalty-free so I won't get sued by anybody down the road).
- changed enemies particle system (the fluffy stuff coming out of them)

I enjoyed working on this project and I am planning on making other little games because I had so much fun with this one. :D
