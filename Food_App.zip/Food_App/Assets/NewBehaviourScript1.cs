﻿using UnityEngine;
using System.Collections;
using System;

public class NewBehaviourScript1 : MonoBehaviour {
    


    // Update is called once per frame
    void Update ()
    {
        OnMouseDrag();
         {
            float distance_to_screen = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;
            Vector3 pos_move = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, distance_to_screen));
            transform.position = new Vector3(pos_move.x, transform.position.y, pos_move.z);

        }


    }

    private void OnMouseDrag()
    {
        throw new NotImplementedException();
    }
}
