﻿namespace Input.mousePosition
{
    internal class x
    {
    }
}