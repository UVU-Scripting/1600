﻿using UnityEngine;
using System.Collections;

public class PlayerMovement2 : MonoBehaviour {
	
	public float speed = 8.0f;
	
	public float jumpSpeed = 7.0f;
	
	public int jumpCount = 1;
	
	bool isGrounded = true;
	public float maxJump = 2.0f;
	

	// Update is called once per frame
	void Update () 
	{
		
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		if (Input.GetKeyDown(KeyCode.RightArrow))
		{
			rotateMove(180);
		}
		else if (Input.GetKeyDown(KeyCode.LeftArrow))
		{
			rotateMove(-180);
		}
		transform.position += move * speed * Time.deltaTime;
		
		if (Input.GetKeyDown (KeyCode.Space) && jumpCount < 3)
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (jumpCount > maxJump || isGrounded == false)
		{
			jumpSpeed = 0.0f;
		}
		if (jumpCount > maxJump && isGrounded == true) 
		{
			jumpSpeed = 0.0f;
		}


	}
	void OnCollisionEnter (Collision col)
	{
		if (col.gameObject.tag == "Platform1") {
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
		if (col.gameObject.tag == "Platform2") {
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
		if (col.gameObject.tag == "Platform3") {
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
		if (col.gameObject.tag == "Respawn") {
			jumpCount = 0;
			jumpSpeed = 0.0f;
			speed = 0.0f;
		}
	}
	private void rotateMove(int dir)
		{
			gameObject.transform.Rotate(0,dir,0);
		}


}
