﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DeliveryToggle : MonoBehaviour {

	public bool deliveryChoice = false;
	public Button delivery;
	
	// Use this for initialization
	void Start () 
	{
		
		delivery.onClick.AddListener (() => Click ());
		
	}

public void Click ()
	{
		if (deliveryChoice == false)
		{
			deliveryChoice = true;
			Debug.Log (priceCounter.currentTotal);
			priceCounter.currentTotal = (priceCounter.currentTotal +2);
			GameObject currentSalesTotal = GameObject.Find ("Total"); 
			currentSalesTotal.GetComponent<Text>().text = ("  " + (priceCounter.currentTotal).ToString("F2"));


		}
		else if (deliveryChoice == true)
		{
			deliveryChoice = false;
			Debug.Log (priceCounter.currentTotal);
			priceCounter.currentTotal = (priceCounter.currentTotal -2);
			GameObject currentSalesTotal = GameObject.Find ("Total"); 
			currentSalesTotal.GetComponent<Text>().text = ("  " + (priceCounter.currentTotal).ToString("F2"));
			//Debug.Log (deliveryChoice);
		}
	}

}
