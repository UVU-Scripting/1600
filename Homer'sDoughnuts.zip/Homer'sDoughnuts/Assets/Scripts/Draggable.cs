﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Draggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {



	//this variable is the parent of the object when you click on it
	//this is where you want the card to return when dropped in an invalid location
	public Transform parentToReturnTo = null;
	public GameObject nextDonut = null;

	public void OnBeginDrag(PointerEventData eventData)
	{

		//this saves the parent when you click on the object
		parentToReturnTo = this.transform.parent;

		//Debug.Log (parentToReturnTo);

		//this changes the parent when you start dragging, to the parent of the parent
		this.transform.SetParent (this.transform.parent.parent);

		//this makes it so when the card is being dragged the raycasts can detect the drop zones
		GetComponent<CanvasGroup>().blocksRaycasts = false;


		/* Commenting this out, I'll come baco to it after the rest of the pricing works.
		 Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
		//int i = System.Int32.Parse(d.name.Substring (15));
		Debug.Log ("This Donut is " + d);
		string donutType = (d.name.Substring (0, 15));
		int donutNumber = (System.Int32.Parse(d.name.Substring (15, 2))-1);
		Debug.Log ("The Next Donut is " + donutType + (donutNumber));
		GameObject nextDonut = GameObject.Find(donutType + donutNumber);
		Debug.Log (nextDonut);

		//nextDonut.SetActive (true);
		//Debug.Log (d.name.Substring (15));
		
		/*for (int i = System.Int32.Parse(d.name.Substring (15, 2)); i > 0; i--)
		{
			GameObject nextDonut = GameObject.Find (donutType + (donutNumber-1));

			nextDonut.SetActive(true);
		}*/

	} 
	public void OnDrag(PointerEventData eventData)
	{
		//this is what allows the card to move. 
		this.transform.position = eventData.position;

	} 
	public void OnEndDrag(PointerEventData eventData)
	{
		//returns the card to where it was when the mouse key is released
		this.transform.SetParent (parentToReturnTo);

		//this re-enables the raycasting once the card is dropped so it can be picked up again
		GetComponent<CanvasGroup>().blocksRaycasts = true;

	} 


}
