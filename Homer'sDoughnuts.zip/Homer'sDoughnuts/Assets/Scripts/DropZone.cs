﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class DropZone : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler {


	public void OnDrop(PointerEventData eventData)
	{
		//Debug.Log (eventData.pointerDrag.name + " was dropped on " + gameObject.name);
		//eventData.pointerDrag is the object being dragged

		//This is what Drops the item you are dragging onto a different item with the dropzone script attached.
		Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
			if (d != null)
				{
					d.parentToReturnTo = this.transform;
				}

		//this video https://www.youtube.com/watch?v=P66SSOzCqFU - this point 25.17
		//I need to change the script so that it drops on it's original parent if dropped on null

	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		
	}

	public void OnPointerExit(PointerEventData eventData)
	{

	}

}
