﻿using UnityEngine;
using System.Collections;

public class fillInventory : MonoBehaviour {
	
	//static GameObject donut;
	
	/*void Awake()
	{
		donut = GameObject.Find ("ObjectPool").GetComponent<GameObject>();
	}*/
	
	// Use this for initialization
	void Start () 
	{
		//objectPool activate = GameObject.Find ("ObjectPool").GetComponent<objectPool>();
	}
	
	
}
