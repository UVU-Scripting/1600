﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class priceCounter : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler {

	public static float subTotal = 0f;
	private static float salesTax = 0.047f;
	public static float currentTax = 0;
	public static float currentTotal = 0;

	public void OnDrop(PointerEventData eventData)
	{
		//Debug.Log (eventData.pointerDrag.GetComponent<Draggable>().tag);
		//Calculate the subtotal when a donut is droped in the price area - this is easily breakable at the moment, for instance you can redrop the same donut in the price total and it ups the price
		subTotal = subTotal + float.Parse(eventData.pointerDrag.GetComponent<Draggable>().tag);

		//Calculate the sub total and place it in the interface
		GameObject subTotalPrice = GameObject.Find ("SubTotal"); 
		subTotalPrice.GetComponent<Text>().text = ("  " + (subTotal).ToString("F2"));

		//Calculates the Current Tax
		currentTax = (salesTax * subTotal);

		//Displays the Current tax in the interface
		GameObject currentSalesTax = GameObject.Find ("Sales Tax"); 
		GameObject currentSalesTaxDollar = GameObject.Find ("Sales Tax $");

		currentSalesTax.GetComponent<Text>().text = ("  " + (currentTax).ToString("F2"));
		if (currentTax > 0){
			currentSalesTaxDollar.GetComponent<Text>().enabled = true; 
		}else {currentSalesTaxDollar.GetComponent<Text>().enabled = false; }
		//Calculates the total price
		currentTotal = subTotal + currentTax;

		//Displays the Current Total
		GameObject currentSalesTotal = GameObject.Find ("Total"); 
		currentSalesTotal.GetComponent<Text>().text = ("  " + (currentTotal).ToString("F2"));






		//Debug.Log ("sales tax is " + salesTax);
		//Debug.Log ("Current tax is " + currentTax);
		//Debug.Log ("SubTotal is " + subTotal);
		//Debug.Log ("Current Totel is " + currentTotal);

	}
	
	public void OnPointerEnter(PointerEventData eventData)
	{
		
	}
	
	public void OnPointerExit(PointerEventData eventData)
	{
		
	}
}
