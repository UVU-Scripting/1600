﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class donut : MonoBehaviour
{
	public Text subtotalText;
	private float subtotal;
	private float taxAmount;
	private float taxTotal;
	private float total;
	public Text taxText;
	public Text totalText;



	void Start ()
	{
		subtotal = 0;
		SetSubtotal ();
		SetTaxes ();
		total = 0;
		SetTotal ();
	}
		

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.CompareTag("$1.09"))
		{
			subtotal = subtotal + 1.09f;
			SetSubtotal ();

		}
		if (other.gameObject.CompareTag("$1.59")) 
		{
			subtotal = subtotal + 1.59f;
			SetSubtotal ();

		}
		if (other.gameObject.CompareTag("$0.99")) 
		{
			subtotal = subtotal + 0.99f;
			SetSubtotal ();

		}
		if (other.gameObject.CompareTag("$1.19")) 
		{
			subtotal = subtotal + 1.19f;
			SetSubtotal ();


		}
		if (other.gameObject.CompareTag("$2.99")) 
		{
			subtotal = subtotal + 2.99f;
			SetSubtotal ();

		}
		if (other.gameObject){
			taxTotal = subtotal *  0.047f;
			SetTaxes ();
		}
		if (other.gameObject){
			total = subtotal + taxTotal;
			SetTotal ();
		}
	}

	void OnTriggerExit2D(Collider2D other)
	{
		if (other.gameObject.CompareTag ("$1.09")) {
			subtotal = subtotal - 1.09f;
			SetSubtotal ();
			taxTotal = taxTotal - 0.05f;
			SetTaxes ();

		}
		if (other.gameObject.CompareTag ("$1.59")) {
			subtotal = subtotal - 1.59f;
			SetSubtotal ();
			taxTotal = taxTotal - 0.07f;
			SetTaxes ();


		}
		if (other.gameObject.CompareTag ("$0.99")) {
			subtotal = subtotal - 0.99f;
			SetSubtotal ();
			taxTotal = taxTotal - 0.05f;
			SetTaxes ();
		

		}
		if (other.gameObject.CompareTag ("$1.19")) {
			subtotal = subtotal - 1.19f;
			SetSubtotal ();
			taxTotal = taxTotal - 0.06f;
			SetTaxes ();


		}
		if (other.gameObject.CompareTag ("$2.99")) {
			subtotal = subtotal - 2.99f;
			SetSubtotal ();
			taxTotal = taxTotal - 0.14f;
			SetTaxes ();
		}
			

		if (other.gameObject){
			total = subtotal - taxTotal;
			SetTotal ();
		}
	}

	void SetSubtotal ()
	{	
		
		subtotalText.text = "Subtotal: $" + subtotal.ToString ("F2");

	}
	void SetTaxes ()
	{	

		taxText.text = "Tax: $" + taxTotal.ToString("F2");

	}
	void SetTotal ()
	{
		totalText.text = "Total: $" + total.ToString ("F2");
	}
		

	void OnGUI() {

		if (GUI.Button (new Rect (700, 475, 90, 20), "Delivery $10")) 
		{
			totalText.text = "Total: $" + 1f + total.ToString ("F2");	
			if (total > 10) {
				totalText.text = "Total: Free Delivery $" + total.ToString ("F2");
			}
		}

		if (GUI.Button (new Rect (800, 475, 99, 20), "Free Carry Out")) 
		{
			totalText.text = "Total: Carryout $" + total.ToString ("F2");

		}
			
}
}