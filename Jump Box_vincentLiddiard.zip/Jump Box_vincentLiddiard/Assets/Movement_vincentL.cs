﻿using UnityEngine;
using System.Collections;

public class Movement_vincentL : MonoBehaviour {


	public float speed = 8.0f;

	public float jumpSpeed = 7.0f;
	
	// Update is called once per frame
	void Update () {

		//movement of player/cube

		//this is one variable that gets the axis of movement from the input from the player
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		transform.position += move * speed * Time.deltaTime;

		//jumping of player/cube
	if (Input.GetKeyDown (KeyCode.Space)) {
			//update of the jump.
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
		}
	}
}
