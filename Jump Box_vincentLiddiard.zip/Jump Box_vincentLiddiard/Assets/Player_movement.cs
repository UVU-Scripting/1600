﻿using UnityEngine;
using System.Collections;

public class Player_movement : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//create variable for forward movement
		int forward = 0;
		//create variable for backward movement
		int backward = 0;
		//create variable for jump
		int jump = 0;


	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
