﻿using UnityEngine;
using System.Collections;

public class ReferenceVariableExample : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Transform trans = transform;
		trans.position = new Vector3 ( 0, 5, 0);
	}

}
