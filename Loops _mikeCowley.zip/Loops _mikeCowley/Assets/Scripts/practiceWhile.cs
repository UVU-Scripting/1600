﻿using UnityEngine;
using System.Collections;

public class practiceWhile : MonoBehaviour {

	int trees = 5;

	// Use this for initialization
	void Start () {
	while(trees > 1 ){
			trees --;
			Debug.Log("Trees are going... going, only " + trees + " left.");
		}
		print("Trees are gone.");
	}
}
