﻿using UnityEngine;
using System.Collections;

public class valueVarableExample : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Vector3 pos = transform.position;
		pos = new Vector3 (0, 5, 0);
	}

}
