﻿using UnityEngine;
using System.Collections;

public class whileLoop : MonoBehaviour {

	int Goombas = 11;
	
	// Use this for initialization
	void Start () {
		while (Goombas >= 0 ) {
			Goombas --;
			Debug.Log ("One Goomba has been smashed! Goomba count " + Goombas);
		}

		print("All the Goombas are smashed...Go Mario!");
	}
}