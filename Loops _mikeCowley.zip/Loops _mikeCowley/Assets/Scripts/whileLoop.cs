﻿using UnityEngine;
using System.Collections;

public class whileLoop : MonoBehaviour {

	int Goombas = 12;
	
	// Use this for initialization
	void Start () {
		while (Goombas >= 1 ) {
			Goombas --;
			Debug.Log ("One Goomba has been smashed! Goomba count " + Goombas);
		}

		print("All the Goombas are smashed...Go Mario!");
	}
}