﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript3 : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        string[] strings = new string[4];
        //array of 7 items
        strings[0] = "This is my Grocery List";
        strings[1] = "Milk";
        strings[2] = "Cocoa Puffs Cereal";
        strings[3] = "Can of Black Beans";
        strings[4] = "Donuts";
        strings[5] = "Butter";



        foreach (string item in strings)
        {
            print(item);
        }
    }
}

