﻿using UnityEngine;
using System.Collections;

public class WhileLoops : MonoBehaviour 
{

	int goombaCount = 1;

	// Use this for initialization
	void Start () 
	{
	   while (goombaCount>0) 
		{
			Debug.Log ("One Goomba has been smashed! Goomba Count 11");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 10");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 9");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 8");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 7");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 6");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 5");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 4");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 3");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 2");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 1");

			Debug.Log ("One Goomba has benn smashed! Goomba Count 0");

			print("All the Goombas are smashed! Go Mario!");

			goombaCount --;
		}
	}
}
