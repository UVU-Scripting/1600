﻿using UnityEngine;
using System.Collections;

public class Script_1 : MonoBehaviour {
    string one_Goomba = "One Goomba has been smashed! ";
    string all_Goomba = "All the Goombas are smashed...Go Mario!";
    string goomba_Count = "Goomba count ";

    int count = 12;

	// Use this for initialization
	void Start () {
        Mario_Smash();
	}
	
	void Mario_Smash () {
        while (count != 0)
        {
            count--;
            print(one_Goomba + goomba_Count + count.ToString());
        }
        print(all_Goomba);
    }
}
