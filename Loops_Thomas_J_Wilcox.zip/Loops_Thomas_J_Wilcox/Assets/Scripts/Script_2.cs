﻿using UnityEngine;
using System.Collections;

public class Script_2 : MonoBehaviour {

    string[] grocery_List = new string[] {"This is my Grocery List", "Milk", "Navel Oranges", "Cocoa Puffs Cereal", "Can of Black Beans", "Donuts", "Butter"};

	// Use this for initialization
	void Start () {
        My_Grocery_List();
	}
	
    void My_Grocery_List() {
        foreach (string element in grocery_List)
            print(element);
    }
}
