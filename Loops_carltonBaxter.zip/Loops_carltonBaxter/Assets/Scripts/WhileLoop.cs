﻿using UnityEngine;
using System.Collections;

public class WhileLoop : MonoBehaviour {
	
		int goombaCount = 12;
		
		// Use this for initialization
		void Start () 
		{
			while (goombaCount > 0) {
				Debug.Log ("One Goomba has been smashed! Goomba count 11");
				
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 10");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 9");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 8");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 7");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 6");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 5");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 4");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 3");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 2");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 1");
			goombaCount --;
			Debug.Log ("One Goomba has been smashed! Goomba count 0");
			goombaCount --;
		
		
		
		}
		{
			print ("All of the Goombas are smashed... Go Mario!");
		}

	}

}
