﻿using UnityEngine;
using System.Collections;

public class foreach_kristaBice : MonoBehaviour 
{

	// Use this for initialization
	void Start () 
	{
		string[] mygrocerylist = new string[7];
		//array of 6 items
		mygrocerylist [0] = "This is my Grocery List";
		mygrocerylist [1] = "Milk";
		mygrocerylist [2] = "Navel Oranges";
		mygrocerylist [3] = "Cocoa Puffs Cereal";
		mygrocerylist [4] = "Can of Black Beans";
		mygrocerylist [5] = "Donuts";
		mygrocerylist [6] = "Butter";

		foreach (string item in mygrocerylist)
		{
			print (item);
		}

	
	}
	

}
