﻿using UnityEngine;
using System.Collections;

public class whileloops_kristaBice : MonoBehaviour 
{
	int Goombas = 12;
	// Use this for initialization
	void Start () 
	{
		while (Goombas > 0) 
		{
			Debug.Log ("One Goomba has been smashed! Goomba count " + Goombas);
			Goombas--;
		}
		print ("All the Goombas are smashed...Go Mario!");
	
	}
	

}
