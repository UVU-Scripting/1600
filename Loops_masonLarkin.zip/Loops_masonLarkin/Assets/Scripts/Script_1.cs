﻿using UnityEngine;
using System.Collections;

public class Script_1 : MonoBehaviour {

	int goombas = 11;
	
	
	void Start ()
	{
		while (goombas >= 0) {
			Debug.Log ("One Goomba has been smashed! Goomba Count " + goombas); 
			goombas--;
				
		}
		print("All the Goombas are smashed...Go Mario!");
	}
}