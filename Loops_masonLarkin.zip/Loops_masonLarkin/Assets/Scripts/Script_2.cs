﻿using UnityEngine;
using System.Collections;

public class Script_2 : MonoBehaviour {

	void Start () 
	{
		string[] groceryList = new string[7];

		groceryList [0] = "This is my grocery list";
		groceryList [1] = "milk";
		groceryList [2] = "Navel Oranges";
		groceryList [3] = "Cocoa Puffs Cereal";
		groceryList [4] = "Can of Black Beans";
		groceryList [5] = "Donuts";
		groceryList [6] = "Butter";

			foreach(string item in groceryList)
			{
				print (item);
			}




	}

}

