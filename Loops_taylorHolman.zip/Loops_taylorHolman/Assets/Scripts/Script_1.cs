﻿using UnityEngine;
using System.Collections;

public class Script_1 : MonoBehaviour {

	int goombasLeft = 11;
	
	// Use this for initialization
	void Start () 
	{
		while (goombasLeft >= 0) 
		{
			Debug.Log("One Goomba has been smashed! Goomba count: " + goombasLeft);
			
			goombasLeft --;

		}
		bool shouldContinue = false;
		
		do 
		{
			print ("All the Goombas are smashed...Go Mario!");
		} while (shouldContinue == true);

	}
}
