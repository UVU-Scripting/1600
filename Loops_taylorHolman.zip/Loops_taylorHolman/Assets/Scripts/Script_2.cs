﻿using UnityEngine;
using System.Collections;

public class Script_2 : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		string[] groceryList = new string[7];
		
		groceryList [0] = "This is my Grocery List";
		groceryList [1] = "Ground Beef";
		groceryList [2] = "Cheddar Cheese";
		groceryList [3] = "Hamburger Buns";
		groceryList [4] = "Lettuce";
		groceryList [5] = "Onions";
		groceryList [6] = "Mayo";
		
		foreach (string grocery in groceryList) 
		{
			print (grocery);
		}
	}
}
