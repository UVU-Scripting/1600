﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour 
{
	int goombaThingy = 12;

	// Use this for initialization
	void Start () 
	{
			for (int i = 0; i < 12; i++)
		{
			goombaThingy--;
			Debug.Log ("One Goomba has been smashed! Goomba count " + goombaThingy);
		}
		{
			print ("All the Goomba are smashed...Go Mario!");
		} 
	}
}
