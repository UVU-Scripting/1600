﻿using UnityEngine;
using System.Collections;

public class grocerylist : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		bool groceryList = false;

		do {
			print ("This is my grocery list");
		} while(groceryList == true);

		string[] strings = new string[6];

		strings [0] = "2% Milk";
		strings [1] = "Whole Wheat Bread";
		strings [2] = "Jazz Apples";
		strings [3] = "Ribeye Steak";
		strings [4] = "Goldfish Crackers";
		strings [5] = "Carrots";

		foreach (string item in strings) 
		{
			print (item);
		}
	}
	

}
