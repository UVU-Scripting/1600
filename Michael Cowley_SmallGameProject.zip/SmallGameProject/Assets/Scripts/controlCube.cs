﻿using UnityEngine;
using System.Collections;

public class controlCube : MonoBehaviour {

	public float moveSpeed;
	public float jumpSpeed = 5.0f;
	public int jumpCount = 1;
	public int maxJump = 2;
	//bool isGrounded = true;

	// Use this for initialization
	void Start () {
		moveSpeed = 10f;
	}
	
	// Update is called once per frame
	void Update () {

		transform.Translate (moveSpeed*Input.GetAxis("Horizontal")*Time.deltaTime,0f,0f);

		//Move cube right and left
		if (Input.GetKeyDown (KeyCode.Space)) {
			transform.position += Vector3.up * moveSpeed * Time.deltaTime * 10;
		}
		//Jump cube
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			transform.position += Vector3.right * moveSpeed * Time.deltaTime * 10;
			jumpCount ++;
		}
		/* Start of next section:
		if (jumpCount > maxJump || isGrounded == false) {
			jumpSpeed = 0.0f;
		}
		if (jumpCount > maxJump && isGrounded == true) {
			jumpSpeed = 0.0f;
			jumpCount = 1;
		}

	void (OnCollisionEnterCollision col){
			if (col.gameObject. == "Player"){
				jumpCount = 2;
				jumpSpeed = 
			}
		}
		//Detect when player is on ground
		*/

		/* Other way to make object jump.
		if(Input.GetKeyDown (KeyCode.Space)) {	
			GetComponent<Rigedbody> ().velocity += Vector3.up * moveSpeed;
		}
		 */
	}
}

