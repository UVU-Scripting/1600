﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class tallyCount2 : MonoBehaviour {

	int tally;

	public Text countDisplay;
	public Button increment;
	public Button decrement;
	public Button reset;
	public AudioSource incSound;
	public AudioSource decSound;
	public AudioSource resetSound;

	// Use this for initialization
	void Start () {
		tally = 0;

		//added a listener
		increment.onClick.AddListener (() => Increment ());
		decrement.onClick.AddListener (() => Decrement ());
		reset.onClick.AddListener (() => Reset ());
	}
	//update is called once per frame
	void Update () {
		countDisplay.text = "Current Tally = " + tally;

		if (tally == 0) {
			decrement.interactable = false;   //disables decrement button
			reset.interactable = false;       //disables reset button
		}

	}
	// Functions called when button is clicked
	void Increment() {
		incSound.Play();				//play the increment sound
		tally ++;						//increment the number
		decrement.interactable = true;	//enabling the Decrement button to be used
		reset.interactable = true;		//enabling the Reset button to be used
	}

	void Decrement() {
		if (tally > 0) {
			decSound.Play();			//play the decrement sound
			tally --;					//decrement the number
		}
	}

	void Reset (){
		resetSound.Play ();				//play the reset sound
		tally = 0;						//reset the number to zero

	}



}
/*notes:
Botton myButton;

void start () {
myButton.onClick.AddListener(() => Increment());
}

void Increment () {
tally ++;
}
*/