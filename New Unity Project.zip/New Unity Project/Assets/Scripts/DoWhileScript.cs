﻿using UnityEngine;
using System.Collections;

public class DoWhileScript : MonoBehaviour 
{

	// Use this for initialization
	void Start () 
	{
		bool shouldContinue = false;
	
	
	
	do 
		{
			print ("Need more donuts");
	   } 

		while(shouldContinue == true);
	}

}