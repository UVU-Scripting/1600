﻿using UnityEngine;
using System.Collections;

public class ForEachLoopExample : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		string[] strings = new string[4];
		//array of 4 items
		strings[0] = "Chocolate donut";
	strings[1] = "Creme-filled donut";
	    strings[2] = "Glazed donut";
		strings[3] = "Maple-Bacon donut";

		foreach(string item in strings)
		{
			print (item);
		}

	
	}
}
