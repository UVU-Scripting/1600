﻿using UnityEngine;
using System.Collections;

public class ForLoopExample : MonoBehaviour {
	int numDonuts = 13;

	// Use this for initialization

	void Start () 
	{
		for (int i = 0; i < numDonuts; i ++)
	    {
		   Debug.Log("Baking donut number" + i);
		}
	}
	

	
	
}
