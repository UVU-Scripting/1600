using UnityEngine;
using System.Collections;

public class LoopsAssignment2_michaylaMcGuire : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	
	{
		string[] strings = new string[7];
		//array of 7 items
		strings[0] = "This Is My Grocery List";
		strings[1] = "Milk";
		strings[2] = "Navel Oranges";
		strings[3] = "Cocoa Puffs Cereal";
		strings[4] = "Can of Black Beans";
		strings[5] = "Donuts";
		strings[6] = "Butter";

		foreach(string item in strings)
			{
			Debug.Log (item);

			}
	
	}
}

