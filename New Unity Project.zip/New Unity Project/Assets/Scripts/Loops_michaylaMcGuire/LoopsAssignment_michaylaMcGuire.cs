using UnityEngine;
using System.Collections;

public class LoopsAssignment_michaylaMcGuire : MonoBehaviour{

	// Use this for initialization
	int goombas = 12; 

		void Start ()
		{ 

		while (goombas > 0) 
		{

			goombas --;
			

			Debug.Log ("One Goomba has been smashed! Goomba count" + goombas);

		}
	

			Debug.Log ("All the Goombas are smashed...Go Mario!");
		
	}

		
}

	
	


	


