﻿using UnityEngine;
using System.Collections;

public class NoReturnFunction : MonoBehaviour {

	int myInt = 5;
	// Use this for initialization
	void Start () 
	{
		myInt = 55;

		Debug.Log (myInt);
	}
	

	
}			 

