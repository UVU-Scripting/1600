﻿using UnityEngine;
using System.Collections;

public class Whilescript : MonoBehaviour {

	// Use this for initialization
	int donutsInTheBox = 13;

	void Start () 
	{
		while (donutsInTheBox > 0) 
		{
			Debug.Log ("I've eaten a donut!");

			donutsInTheBox --;
		}


	}
	
}

