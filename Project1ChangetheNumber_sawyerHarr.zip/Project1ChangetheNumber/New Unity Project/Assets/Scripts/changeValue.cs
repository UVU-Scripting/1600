﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class changeValue : MonoBehaviour {
	public Text countDisp;
	int count = 0;
	void Start () {
		print ("Button Layout: A=+1, S=-1, R=Reset.");
		countDisp.text = "" + count;
	}
	void Update () {
		if (Input.GetKeyDown(KeyCode.A)) {
			count++;	
			print (count);
			countDisp.text = "" + count;}
		if ((Input.GetKeyDown(KeyCode.S)) && (count>0)) {
			count--;	
			print (count);
			countDisp.text = "" + count;}
		if (Input.GetKeyDown(KeyCode.R) && (count!=0)) {
			count = 0;	
			print (count);
			countDisp.text = "" + count;}
	}
}
