﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class instructions : MonoBehaviour {

	void Start () {
	
	}
}