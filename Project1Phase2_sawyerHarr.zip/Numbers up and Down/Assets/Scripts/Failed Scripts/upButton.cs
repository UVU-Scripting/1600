﻿using UnityEngine;
using System.Collections;

public class upButton : MonoBehaviour {
	public GameObject numberTotal;
	public changeValue changeValueuB;
	void Start () {
		numberTotal = GameObject.Find("numberTotal");
		changeValueuB = numberTotal.GetComponent<changeValue> ();
		changeValueuB.count++;
	}
}
