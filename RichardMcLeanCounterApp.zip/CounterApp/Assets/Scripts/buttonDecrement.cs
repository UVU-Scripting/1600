﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class buttonDecrement : MonoBehaviour {

	public Button decrement;

	// Use this for initialization
	void Start () 
	{
		decrement.onClick.AddListener (() => Click ());
	}
	
	// Update is called once per frame
	public void Click () 
	{

		if (keyCounter.keyCountNumber > 0)
		{
			AudioSource audio = GetComponent<AudioSource>();
			audio.Play();
			keyCounter.keyCountNumber = keyCounter.keyCountNumber - 1;
		}
	}
}
