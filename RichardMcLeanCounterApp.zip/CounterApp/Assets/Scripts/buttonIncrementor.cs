﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class buttonIncrementor : MonoBehaviour 
{
	public Button increment;
	
	void Start ()
	{
		increment.onClick.AddListener (() => Click ());
	}

	// Update is called once per frame
	public void Click () 
	{

		{
			AudioSource audio = GetComponent<AudioSource>();
			audio.Play();
			keyCounter.keyCountNumber = keyCounter.keyCountNumber + 1;
		}
	}
}
