﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class guiBehavior : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{

		GameObject Counter = GameObject.Find ("counter"); 
		Counter.GetComponent<Text>().text = (""+(keyCounter.keyCountNumber));

		if (keyCounter.keyCountNumber == 0) {
			GameObject.Find ("decrementButton").GetComponent<Button> ().interactable = false; 
			GameObject.Find ("resetButton").GetComponent<Button>().interactable = false; 
		} 
		else if (keyCounter.keyCountNumber > 0) {
			GameObject.Find ("decrementButton").GetComponent<Button> ().interactable = true; 
			GameObject.Find ("resetButton").GetComponent<Button>().interactable = true; 
		}

	
	}
}
