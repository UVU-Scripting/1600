﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class keyCounter : MonoBehaviour {
	
	public static int keyCountNumber = 0;
	
	
	// Use this for initialization
	void Start () 
	{


		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
		
		if(Input.GetKeyDown(KeyCode.UpArrow))
		{
			keyCountNumber = keyCountNumber + 1;
			//print (keyCountNumber);
		}

		if(Input.GetKeyDown(KeyCode.DownArrow))
		{
			keyCountNumber = keyCountNumber - 1;
			//print (keyCountNumber);
		}
		
		
		if(Input.GetKey (KeyCode.Space))
		{
			keyCountNumber = 0;

		}
		
		if (keyCountNumber < 0) 
		{
			keyCountNumber = 0;
			
		}
	}
	
}