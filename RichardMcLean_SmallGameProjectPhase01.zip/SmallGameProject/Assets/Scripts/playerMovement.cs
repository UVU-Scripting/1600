﻿using UnityEngine;
using System.Collections;

public class playerMovement : MonoBehaviour {

	public float moveSpeed = 10f;
	public float JumpHeight = 50f;
	public float maxAngleDown = 0f;

	private bool isJumping = false;
	private bool isJumping2 = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		//resets rotation if character starts to tip
		/*if (transform.eulerAngles.x < maxAngleDown || transform.eulerAngles.x > maxAngleDown)
		{
			/*Vector3 newPos = new Vector3 (0, 0, 0);
			transform.position = newPos;
			transform.rotation = Quaternion.Euler (0, 0, 0);
		}*/

		if(Input.GetKeyDown(KeyCode.Space))
		{ 
			//rigidbody.AddForce(transform.up * JumpHeight); 
			if (isJumping == false)
			{
			
			GetComponent<Rigidbody>().AddForce(new Vector3(0, JumpHeight, 0), ForceMode.Impulse);
			isJumping = true;

			}
			else if (!isJumping2) 
			{

			GetComponent<Rigidbody>().AddForce(new Vector3(0, JumpHeight, 0), ForceMode.Impulse);
			isJumping2 = true;
			
			}
			Debug.Log (isJumping);
			Debug.Log (isJumping2);

		}


		//Moves Left and right along x Axis                               //Left/Right
		transform.Translate(Vector3.right * Time.deltaTime * Input.GetAxis("Horizontal")* moveSpeed);
	
	}
	//resets isJumping bool when player collides with ground objects
	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.tag == "Ground")
		{
			isJumping = false;
			isJumping2 = false;
		}

	}

}
