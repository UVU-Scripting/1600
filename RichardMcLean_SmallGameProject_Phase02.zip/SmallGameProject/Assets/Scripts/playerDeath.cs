﻿using UnityEngine;
using System.Collections;

public class playerDeath : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.tag == "Death")
		{
			Vector3 newPos = new Vector3 (-5.51f, -0.31f, 0f);
			transform.position = newPos;
		}
		
	}
}
