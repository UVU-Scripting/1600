﻿using UnityEngine;
using System.Collections;

public class playerMovement : MonoBehaviour {

	private float moveSpeed = 15f;
	private float jumpHeight = 100f;
	public float maxAngleDown = 0f;

	private bool isJumping = false;
	private bool isJumping2 = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		//resets rotation if character starts to tip
		/*if (transform.eulerAngles.x < maxAngleDown || transform.eulerAngles.x > maxAngleDown)
		{
			/*Vector3 newPos = new Vector3 (0, 0, 0);
			transform.position = newPos;
			transform.rotation = Quaternion.Euler (0, 0, 0);
		}*/

		if(Input.GetKeyDown(KeyCode.Space))
		{ 
			//rigidbody.AddForce(transform.up * JumpHeight); 
			if (isJumping == false)
			{
			
			GetComponent<Rigidbody>().AddForce(new Vector3(0, jumpHeight, 0), ForceMode.Impulse);
			isJumping = true;

			}
			else if (!isJumping2) 
			{

			GetComponent<Rigidbody>().AddForce(new Vector3(0, jumpHeight, 0), ForceMode.Impulse);
			isJumping2 = true;
			
			}


		}


		//Moves Left and right along x Axis                                //Left/Right
		//transform.Translate (Vector3.right * Time.deltaTime * Input.GetAxis ("Horizontal") * moveSpeed);
		GetComponent<Rigidbody> ().transform.Translate (Vector3.right * Time.deltaTime * Input.GetAxis ("Horizontal") * moveSpeed);

	}
	//resets isJumping bool when player collides with ground objects
	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.tag == "Ground")
		{
			isJumping = false;
			isJumping2 = false;
		}

	}

}
