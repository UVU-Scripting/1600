Nightmares 1.1


-Added Sprint Feature (Shift Key)

	You can sprint as long as you have energy. Energy regenerates by killing
	enemies or by drinking an Energy Drink.


-Added Player Bomb Weapon (Space Key)

	Bombs currently can only be dropped every 6 seconds. They have applied

	rigid bodies, so they will move if bumped into.
	Also, there is a chance
	that enemies will drop bombs upon death. Trains
	do not drop bombs.


-Added Player Shield (V Key)
	Enemies have a chance of dropping a small golden shield. Once picked up,
	this shield will give the player one use of his shield. Shileds make a
	barrier between the player and mobs. The shield does NOT protect you from
	explosion damage, though!

-Added Pause Menu (Escape Key)

-Added Inferno Spell (E Key)
	The Inferno Spell becomes available after earning 1000 points. Once used,
	you will have to earn another 1000 points to use it again.
	An Icon will appear at the bottom right of the screen to let you know when
	this ability is ready for use.

-Added Monster Energy Drinks

	Drinks will have a 1 in 10 chance of instantiating on death of an enemy (50%

	chance for train enemy)
	Drinks will significantly increase your firing speed
	for 5 seconds. Each drink.

	increases the timer for an additional 5 seconds.

	Screen flashes green while increased speed is active

	Drinks give you player sprint energy


-Added Health Packs

	Health Packs that heal 50 points will spawn at assigned spawn points if the

	player falls below 50 health

	Smaller health packs that heal 20 health will spawn at random on death of

	any enemy.


-Added Weapon Upgrades

	-Permanent Speed Upgrade

		Your gun will double in shooting speed

		Spawns currently at 1000 points

	-3X Upgrade

		Gun permanently shoots three bullets in a spray instead of one

		Spawns at 2000 points


-Changed background Music


-Added Exploding Train

	Trains will explode after 3 seconds when they have either been killed or after

	3 seconds when they have touched the player. There is a visual blast radius.

	Damage effects the player and all enemies except for other trains.

	Spawns at 1500 points


-Added HellBunny

	HellBunnies are giant ZombBunnies that have 10000 health, higher damage,

	and are giant sized. They are also midnight black.

	*Note* They are NOT impossible to kill! If you have the 3X and Gun upgrades,

	they WILL die!

	Spawns at 3500 points


-Changed Enemy Instantiation Rate

	Enemies will spawn faster the longer the game has been playing.

-Added High Score storing