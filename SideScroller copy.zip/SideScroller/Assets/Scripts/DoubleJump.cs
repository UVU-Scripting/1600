﻿using UnityEngine;
using System.Collections;

public class DoubleJump : MonoBehaviour {

	public float speed = 8.0f;
	public float jumpSpeed = 7.0f;
	public int jumpCount = 1;
	public int maxJump = 2;

	public GameObject player;
	 
	bool isGrounded = true;


	// Update is called once per frame
	void Update () 
	{
		//moving an object horizontally and vertically
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		if (Input.GetKeyDown (KeyCode.RightArrow))
		{
			rotateMove(180);
		}
		else if (Input.GetKeyDown (KeyCode.LeftArrow))
		{
			rotateMove(-180);
		}
		transform.position += move * speed * Time.deltaTime;



		//Jumping with a spacebar
		if (Input.GetKeyDown (KeyCode.Space) && maxJump < 3) {
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (jumpCount > maxJump || isGrounded == false) 
		{
			jumpSpeed = 0.0f;
		}
		if (jumpCount > maxJump && isGrounded == true)
		{
			jumpSpeed = 0.0f;
			jumpCount = 1;
		}
	}


	//Resetting the Jump Count
	void OnCollisionEnter(Collision col)
	{
		if (col.gameObject.tag == "Floor01") 
		{
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
		if (col.gameObject.tag == "Floor02") 
		{
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
		if (col.gameObject.tag == "Floor03") 
		{
			jumpCount = 1;
			jumpSpeed = 7.0f;
		}
	}

	//RotateMove
	private void rotateMove(int dir)
	{
		gameObject.transform.Rotate(0, dir, 0);
	}
	
}