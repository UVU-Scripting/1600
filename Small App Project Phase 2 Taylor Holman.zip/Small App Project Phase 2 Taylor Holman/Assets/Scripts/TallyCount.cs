﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TallyCount : MonoBehaviour {

	public Button incrementButton;
	public Button decrementButton;
	public Button resetButton;
	public Text Display;
	public int tally = 0;
	public AudioSource IncrementSound;
	public AudioSource DecrementSound;
	public AudioSource ResetSound;

	// Use this for initialization
	void Start () {
		incrementButton.onClick.AddListener(() => {Increment ();});
		decrementButton.onClick.AddListener(() => {Decrement ();});
		resetButton.onClick.AddListener(() => {Reset ();});
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown (KeyCode.A)) {
			Increment();
		}
		if (Input.GetKeyDown (KeyCode.S)) {
			Decrement();
		}
		if (Input.GetKeyDown (KeyCode.R)) {
			Reset ();
		}
		//Display.text = tally.ToString ();
	}

	void Increment(){
		++tally;
		Display.text = tally.ToString();
		IncrementSound.Play ();
	}
	void Decrement(){
		if (tally > 0) {
			--tally;
			Display.text = tally.ToString();
			DecrementSound.Play ();
		}
	}
	void Reset(){
		tally = 0;
		Display.text = tally.ToString();
		ResetSound.Play ();
	}

}
