﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SmallProjectPhase1 : MonoBehaviour {

	public int tally = 0;
	public Button incrementButton;
	public Button decrementButton;
	public Button resetButton;
	public Text Tally;

	void Start(){
		incrementButton.onClick.AddListener (() => increment ());
		decrementButton.onClick.AddListener (() => decrement ());
		resetButton.onClick.AddListener (() => reset ());
	}

	void Update () {

		//public tallyCount myTally = new tallyCount();

		if (Input.GetKeyDown (KeyCode.A))
		{
			increment();

		}

		if (Input.GetKeyDown (KeyCode.S)) {
			if (tally > 0) 
			{
				decrement ();
			}
		}
		if (Input.GetKeyDown (KeyCode.R)) 
		{
			reset ();
		}


	}

	void increment(){

		++tally;
		Tally.text = tally.ToString();
	}

	void decrement(){
		if (tally > 0) {
			--tally;
			Tally.text = tally.ToString ();
		}

	}
	void reset(){
		tally = 0;
		Tally.text = tally.ToString();
	}
}
