﻿using UnityEngine;
using System.Collections;

public class AppUpDown : MonoBehaviour 
{
	int tallyInt = 0;
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.A)) 
		{
			tallyInt ++;
			Debug.Log (tallyInt);
		}
	
		if (Input.GetKeyDown (KeyCode.S)) 
		
		{
			if(tallyInt > 0)
			{
				tallyInt --;
				Debug.Log (tallyInt);
			}
		}

		if (Input.GetKeyDown (KeyCode.R)) 
			{
				tallyInt=0;
				Debug.Log (tallyInt);

			}

	}
}
