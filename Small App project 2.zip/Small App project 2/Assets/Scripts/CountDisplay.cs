﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CountDisplay : MonoBehaviour {
	
	public Button incrementButton;
	public Button decrementButton;
	public Button resetButton;
	public Text Display;
	public int tally = 0;

	
	// use this to make the counter work.
	void Start () {
		incrementButton.onClick.AddListener(() => {Increment ();});
		decrementButton.onClick.AddListener(() => {Decrement ();});
		resetButton.onClick.AddListener(() => {Reset ();});
	}
	
	// use this to make the the keys work with buttons.
	void Update () {
		
		if (Input.GetKeyDown (KeyCode.A)) {
			Increment();
		}
		if (Input.GetKeyDown (KeyCode.S)) {
			Decrement();
		}
		if (Input.GetKeyDown (KeyCode.R)) {
			Reset ();
		}

	}
	//use this to make the text go up.
	void Increment(){
		++tally;
		Display.text = tally.ToString();

	}
	//use this to make the text go down.
	void Decrement(){
		if (tally > 0) {
			--tally;
			Display.text = tally.ToString();
		
		}
	}
	// use this to make the counter reset.
	void Reset(){
		tally = 0;
		Display.text = tally.ToString();

	}
	
}
