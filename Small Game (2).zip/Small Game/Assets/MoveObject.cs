using UnityEngine;
using System.Collections;

public class MoveObject : MonoBehaviour {

	public float speed = 8.0f;
//	public float jumpSpeed = 7.0f;
//	public float maxJump = 2.0f;

//	bool isGrounded = true;
//	public int jumpCount = 1;

	/*void Start()
	{
		isGrounded = true;
		jumpSpeed = 5f;
	}
	*/

	void Update () 
	{
		// move horizontal and veritcal
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		transform.position += move * speed * Time.deltaTime;

		// spacebar jump
		/*	if (Input.GetKeyDown (KeyCode.Space) && maxJump < 3.0f) 
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (jumpCount > maxJump || isGrounded == false) 
		{
			jumpSpeed = 0.0f;
		}
		if (jumpCount > maxJump && isGrounded == true)
		{
			jumpSpeed = 0.0f;
			jumpCount = 1;
		}
	*/

		//reset position if fall off
		if (transform.position.x >= 12 | transform.position.x <= -11) 
		{
			transform.position = new Vector3(-7, 1, 0);
		}
	}
	/*void OnCollisionEnter (Collision col)
	{
		if (col.gameObject.tag == ("Platform01") ) 
		{
			jumpCount = 1;
			jumpSpeed = 7;
		}
	}
	*/

}
