﻿using UnityEngine;
using System.Collections;

public class jump : MonoBehaviour 
{

	private float jumpSpeed;

	private Rigidbody rBody;
	private bool onGround;
	public int jumpCount = 1;		
	public float maxJump = 2.0f;

	void Start () 
	{
		onGround = true;

		jumpSpeed = 5f;

		rBody = GetComponent<Rigidbody> ();
	}
	

	void Update () 
	{

		if (Input.GetKeyDown(KeyCode.Space) && maxJump < 3.0f) 						
		{
			GetComponent<Rigidbody>().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (jumpCount > maxJump || onGround == false)
		{
			jumpSpeed = 0.0f;
		}
		if (jumpCount > maxJump && onGround == true) 
		{
			jumpSpeed = 0.0f;
			jumpCount = 1;
		}
	}
	void OnCollisionEnter (Collision other)
	{
		if(other.gameObject.CompareTag("Platform01"))

		{
			jumpCount = 1;
			jumpSpeed = 5f;
		}
	}
}















