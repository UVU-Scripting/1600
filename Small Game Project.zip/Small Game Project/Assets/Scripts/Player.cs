﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	private float inputDirection;
	private float verticalvelocity; 

	private float speed = 10.0f; 
	private float gravity = 30.0f;
	private bool secondJumpAvail = false; 

	private Vector2 moveVector;
	private CharacterController controller;


	// Use this for initialization
	void Start () 
	{
		controller = GetComponent<CharacterController> ();
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		inputDirection = Input.GetAxis("Horizontal") * speed; 
		Debug.Log (inputDirection);

		if (controller.isGrounded) 
		{
			verticalvelocity = 0;

			if (Input.GetKeyDown (KeyCode.Space)) 
			{
				verticalvelocity = 10;
				secondJumpAvail = true;
			}
		} 
		else 
		{
			if (Input.GetKeyDown (KeyCode.Space)) 
			{
				if(secondJumpAvail)
				{
					verticalvelocity = 8;
					secondJumpAvail = false;
				}

			}
			verticalvelocity -= gravity * Time.deltaTime;
		}
		moveVector = new Vector2 (inputDirection,verticalvelocity);
		Debug.Log (moveVector);
		controller.Move (moveVector*Time.deltaTime);
	}
}
