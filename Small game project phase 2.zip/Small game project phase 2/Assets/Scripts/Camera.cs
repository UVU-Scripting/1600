﻿using UnityEngine;
using System.Collections;

public class Camera : MonoBehaviour 
{
	public Transform lookAt;

	private Vector3 offset = new Vector3(0,0,-13f);

	private void Start()
	{
		Debug.Log (lookAt.name);
	}

	private void Update()
	{
		transform.position = lookAt.transform.position + offset;
	}
}