﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float speed;
	public float jumpVelocity;																			
	public int maxMultiJumps;

	Rigidbody rb;
	Vector2 input;

	CollisionStatus status;
	
	float threshold = 0.0000001f;
	int jumpsLeft;

	// Use this for initialization
	void Start () {
		status = new CollisionStatus();
		status.Reset();

		rb = GetComponent<Rigidbody>();																	// Use the RigidBody to control movement.
		jumpsLeft = maxMultiJumps;																		// How many times are we allowed to multi-jump?
	}

	// Update is called once per frame.
	void Update () {
		input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));				// Get the horizontal and vertical input.

		// Set facing direction
		if ((status.facingDirection > 0 && input.x < 0) || (status.facingDirection < 0 && input.x > 0)) {
			Flip();
		}

		Vector3 velocity = rb.velocity;																	// Vertical isn't used at the moment, but if we want to use it in the future, we'll have it!
		velocity.x = input.x * speed;																	// input.x will be either 1 or -1.  If we want analog control, use GetAxis() instead.

		if (Input.GetButtonDown("Jump") && (status.below || jumpsLeft > 0)) {							// jumpsLeft lets us check the number of times we've multi-jumped.															
			velocity.y = jumpVelocity;																	// Do the same thing for y as we did for x.
			jumpsLeft--;
		}

		rb.velocity = velocity;																			// We can't set rb.velocity.x directly so we use this local velocity Vector as a stand-in.
	}

	// Called when the Player hits another object.
	void OnCollisionEnter(Collision coll) {
		foreach (ContactPoint contact in coll.contacts) {
			if (contact.normal.y > threshold) {															// Check if the direction of the collision contact is pointing down.
				status.ground = coll.gameObject;
				status.below = true;
				jumpsLeft = maxMultiJumps;																// Reset jumpsLeft so we can multi-jump again.
				break;																					// Exit the foreach loop on the first contact that matches the condition.
			}
		}
	}

	// Called when the Player stops touching another object.
	void OnCollisionExit(Collision coll) {
		if (coll.gameObject == status.ground) {
			status.below = false;
			status.ground = null;
		}
	}

	// Flip the player to face the opposite direction.
	void Flip() {
		Vector3 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;
		status.facingDirection *= -1;
	}

	public struct CollisionStatus {
		public bool below;
		public GameObject ground;
		public int facingDirection;

		public void Reset() {
			below = false;
			ground = null;
			facingDirection = 1;
		}
	}
}
