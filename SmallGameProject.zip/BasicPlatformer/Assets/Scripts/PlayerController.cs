﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float speed;
	public float jumpVelocity;
																					
	public int maxMultiJumps;

	Rigidbody rb;
	Vector2 input;

	bool isGrounded;
	GameObject groundedOn;
	int jumpsLeft;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();																	// Use the RigidBody to control movement.
		jumpsLeft = maxMultiJumps;																		// How many times are we allowed to multi-jump?
	}
	
	// FixedUpdate is called once every Physics Cycle.
	void FixedUpdate () {
		input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));				// Get the horizontal and vertical input.  
		Vector3 velocity = rb.velocity;																	// Vertical isn't used at the moment, but if we want to use it in the future, we'll have it!
		velocity.x = input.x * speed;																	// input.x will be either 1 or -1.  If we want analog control, use GetAxis() instead.
		rb.velocity = velocity;																			// We can't set rb.velocity.x directly so we use this local velocity Vector as a stand-in.
	}

	// Update is called once per frame.
	void Update () {																					// Use Update for the jumps so that they happen on the exact frame we pressed jump.
		if (Input.GetButtonDown("Jump") && (isGrounded || jumpsLeft > 0)) {								// jumpsLeft lets us check the number of times we've multi-jumped.
			Vector3 velocity = rb.velocity;																// Do the same thing for y as we did for x.
			velocity.y = jumpVelocity;
			rb.velocity = velocity;
			jumpsLeft--;
		}
	}

	// Called when the Player hits another object.
	void OnCollisionEnter(Collision coll) {
		foreach (ContactPoint contact in coll.contacts) {
			if (contact.normal.y > 0) {																	// Check if the direction of the collision contact is pointing down.
				isGrounded = true;
				groundedOn = coll.gameObject;
				jumpsLeft = maxMultiJumps;																// Reset jumpsLeft so we can multi-jump again.
				break;																					// Exit the foreach loop on the first contact that matches the condition.
			}
		}
	}

	// Called when the Player stops touching another object.
	void OnCollisionExit(Collision coll) {
		if (coll.gameObject == groundedOn) {
			groundedOn = null;
			isGrounded = false;
		}
	}
}
