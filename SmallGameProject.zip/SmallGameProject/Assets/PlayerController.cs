﻿using UnityEngine;
public class PlayerController : MonoBehaviour {

	public float velocity;
	public Rigidbody rb;
	public float jumpHeight;
	public int jumpcount = 1;
	public bool grounded = false;
	public float speed = 6.0F;
	public float gravity = 20.0F;
	bool facingRight = true;
	public float maxjumps = 2;
	public float jumpspeed = 2F;

	// Use this for initialization
	void Start () {

	}

	void OnCollisionEnter(Collision col)
	{
		if (col.gameObject.tag == "platform") {

			grounded = true;
		}
	}

	// Update is called once per frame
	void Update () {
		rb = GetComponent<Rigidbody>();

		if (Input.GetKeyDown("left"))
		{
			rb.velocity = new Vector3(-velocity,rb.velocity.y);

		}
		if (Input.GetKeyDown("right"))
		{
			rb.velocity = new Vector3(velocity, rb.velocity.y);

		}
		if (Input.GetKeyDown("up"))
		{
			rb.velocity = new Vector3(velocity, rb.velocity.x, velocity);
		}
		if (Input.GetKeyDown("down"))
		{
			rb.velocity = new Vector3(velocity, rb.velocity.x, -velocity);
		}
		if (Input.GetKeyDown("space"))
		{
			grounded = false;
			rb.velocity = new Vector3(0, jumpHeight);
			if(jumpcount>2 && !grounded)
			{
				rb.velocity = new Vector3(0, 0);
				jumpcount = 0;
			}
			jumpcount = jumpcount + 1;  

			if (grounded == true) {
				jumpspeed = 0.0f;
				jumpcount = 1;
			}
		}
		if (Input.GetKeyDown("left")) {
			transform.eulerAngles = new Vector3 (0, 180);
		}
		if (Input.GetKeyDown("right")) {
			transform.eulerAngles = new Vector3 (0, 0);
		}
		if (Input.GetKeyDown("up")) {
			transform.eulerAngles = new Vector3 (0, 0, 90);
		}
		if (Input.GetKeyDown("down")) {
			transform.eulerAngles = new Vector3 (0, 0, -90);
		}
	}
	void Flip()

	{
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

}
