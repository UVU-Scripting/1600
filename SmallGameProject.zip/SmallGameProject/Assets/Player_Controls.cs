﻿using UnityEngine;
using System.Collections;

public class Player_Controls : MonoBehaviour {
    Vector3 zero_Speed = new Vector3(0, 0, 0);

    const int FIVE = 5;
    const int NEGATIVE_FIVE = -5;
    const int TEN = 10;
	
	// Update is called once per frame
	void Update () {
        Jump();
        Forward_Backward_Movement();
	}

    // Forward and Backward Movement
    void Forward_Backward_Movement(){
        // 'A' Moves Backwards
        if (Input.GetKey(KeyCode.A))
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(NEGATIVE_FIVE, gameObject.GetComponent<Rigidbody>().velocity.y, gameObject.GetComponent<Rigidbody>().velocity.z);
        else if (Input.GetKeyUp(KeyCode.A))
            gameObject.GetComponent<Rigidbody>().velocity = zero_Speed;
        // 'D' Moves Forwards
        else if (Input.GetKey(KeyCode.D))
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(FIVE, gameObject.GetComponent<Rigidbody>().velocity.y, gameObject.GetComponent<Rigidbody>().velocity.z);
        else if (Input.GetKeyUp(KeyCode.D))
            gameObject.GetComponent<Rigidbody>().velocity = zero_Speed;
    }

    // Jump
    void Jump(){
        // "Space" Jumps
        if (Input.GetKeyDown(KeyCode.Space))
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(gameObject.GetComponent<Rigidbody>().velocity.x, TEN, gameObject.GetComponent<Rigidbody>().velocity.z);
    }
}
