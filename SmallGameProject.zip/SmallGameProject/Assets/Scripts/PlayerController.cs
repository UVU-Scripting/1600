﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float speed;
	public float jumpSpeed;

	Rigidbody2D rb;
	Vector2 input;
	Vector2 velocity;

	bool isGrounded;
	GameObject groundedOn;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D>();
	}
	
	// FixedUpdate is called once every # of milliseconds.
	void FixedUpdate () {
		input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));				// Get the horizontal and vertical input.  
		velocity = rb.velocity;																			// Vertical isn't used at the moment, but if we want to use it in the future, we'll have it!

		velocity.x = input.x * speed;

		rb.velocity = velocity;
	}

	// Update is called once per frame.
	void Update () {
		if (Input.GetButtonDown("Jump") && isGrounded) {
			rb.AddForce(Vector2.up * jumpSpeed);
		}
	}

	// Called when the Player hits another object.
	void OnCollisionEnter2D(Collision2D coll) {
		foreach (ContactPoint2D contact in coll.contacts) {
			if (contact.normal.y > 0) {																	// Check if the direction of the collision is pointing down.
				isGrounded = true;
				groundedOn = coll.gameObject;
				break;																					// Exit the foreach loop on the first contact that matches the condition.
			}
		}
	}

	// Called when the Player stops touching another object.
	void OnCollisionExit2D(Collision2D coll) {
		if (coll.gameObject == groundedOn) {
			groundedOn = null;
			isGrounded = false;
		}
	}
}
