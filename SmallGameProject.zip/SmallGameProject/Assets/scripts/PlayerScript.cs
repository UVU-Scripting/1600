﻿using UnityEngine;
using System.Collections;

public class PlayerScript : MonoBehaviour
{
	public float speed = 7.0f;
	public float jumpSpeed = 6.0f;

		void Update ()
	{
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis("Vertical"), 0);
		transform.position += move * speed * Time.deltaTime;

		// Jumping with a spacebar
		if (Input.GetKeyDown (KeyCode.Space))
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up *jumpSpeed;
		}
	}
}
