﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
	public float speed = 8.0f;

	public float jumpSpeed = 7.0f;
	public int jumpCount = 1;
	public bool isGrounded = true;
	public float maxJump = 2
	void Update()

	{ 
		//Moving and object Horizontally and vertically
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		                        transform.position += move * speed * Time.deltaTime;
	
		//Making the object jump
		if (Input.GetKeyDown (KeyCode.Space) && maxJump < 2)
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (jumpCount > maxJump || isGrounded == false)
		{
			jumpSpeed = 0.0f;


		}
		if (jumpCount > maxJump && isGrounded == true)
		{
			jumpSpeed 
		}


	}
}



