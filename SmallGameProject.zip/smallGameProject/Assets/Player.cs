﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour 
{
	public float Speed = 7.0f;
	public float jumpSpeed = 7.0f;
	private int jumpCount = 0;
	Vector3 Move;
	public bool doubleJump;
	public bool isGrounded;
	float someScale;
	void Update()
	{


		Move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		transform.position += Move * Speed * Time.deltaTime;


		if (Input.GetKeyDown (KeyCode.Space)&& jumpCount < 2) 
		{

			jumpCount ++;
				GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;


		}
		if (Input.GetKeyDown (KeyCode.LeftArrow))
		{
			transform.forward = new Vector3 (0f, 0f, 1f);
		}
		if (Input.GetKeyDown (KeyCode.RightArrow))
		{
			transform.forward = new Vector3 (0f, 0f, -1f);
		}
		

	}

		void OnCollisionEnter(Collision col)
		{
	
		if (col.gameObject.name == "Platform"){
				jumpCount =0;
				jumpSpeed = 7;
				 
		
			}


		}
	
	
	}
		
		




