﻿using UnityEngine;
using System.Collections;

public class jump : MonoBehaviour 
{
	//private float jumpPressure;
	private float minJump;
	//private	float maxJumpPressure;
	private Rigidbody rBody;
	private bool onGround;
	public int jumpCount = 1;		
	public float maxJump = 2.0f;

	void Start () 
	{
		onGround = true;
		//jumpPressure = 0f;
		minJump = 5f;
		//maxJumpPressure = 10f;
		rBody = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.
		//this code for is for jump that has a pressure sensor.

		/*if (onGround) 
		{
			// holding jumb botton//
			if(Input.GetButton("Jump"))
			{
				if(jumpPressure < maxJumpPressure)
				{
					jumpPressure += Time.deltaTime*10f;
				}
				else
				{
					jumpPressure = maxJumpPressure;
				}
				//print (jumpPressure);
			}
			//not holding jump button//
			else
			{	//jump//
				if(jumpPressure > 0f)
				{
					jumpPressure = jumpPressure + minJump;
					rBody.velocity = new Vector3(jumpPressure/10f,jumpPressure,0f);
					jumpPressure = 0f;
					onGround = false;
				}
			}
		}*/




	

		//this code for is for jump that can double jump and ground but no pressure
		//this code for is for jump that can double jump and ground but no pressure
		//this code for is for jump that can double jump and ground but no pressure
		if (Input.GetKeyDown(KeyCode.Space) && maxJump < 3.0f) 						
		{
			GetComponent<Rigidbody>().velocity += Vector3.up * minJump;
			jumpCount ++;
		}
		if (jumpCount > maxJump || onGround == false)
		{
			minJump = 0.0f;
		}
		if (jumpCount > maxJump && onGround == true) 
		{
			minJump = 0.0f;
			jumpCount = 1;
		}
	}
	void OnCollisionEnter (Collision other)
	{
		if(other.gameObject.CompareTag("ground"))
		//if (col.gameObject.name == "Platform01")     // this is the code I will use insted of the top if i want to use the name of each objects.
		{
			//onGround = true;                         // this is the code I will use if I want to use pressure jump
			jumpCount = 1;
			minJump = 5f;
		}
	}
}















