﻿using UnityEngine;
using System.Collections;

public class speed : MonoBehaviour 
{
	
	public float moveSpeed = 5.0f;
	public float rotateSpeed = 5.0f;
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKey (KeyCode.A)) 
		{
			transform.Translate((Vector3.left)*moveSpeed*Time.deltaTime);
			Debug.Log ("Pressing w");
		}
		if (Input.GetKey (KeyCode.D)) 
		{
			transform.Translate((Vector3.right)*moveSpeed*Time.deltaTime);
			Debug.Log ("Pressing s");
		}
		if (Input.GetMouseButton (0)) //right mouse boost
		{
			moveSpeed = 50.0f;
		}
		if (!Input.GetMouseButton (0)) //right mouse
		{ 
			moveSpeed = 5.0f;
		}
		
		/*
		if (Input.GetKey (KeyCode.W)) 
		{
			transform.Translate((Vector3.forward)*moveSpeed*Time.deltaTime);
			Debug.Log ("Pressing w");
		}
		if (Input.GetKey (KeyCode.S)) 
		{
			transform.Translate((Vector3.back)*moveSpeed*Time.deltaTime);
			Debug.Log ("Pressing s");
		}
		if (Input.GetKey (KeyCode.D)) 
		{
			transform.Rotate(Vector3.up * rotateSpeed);
			Debug.Log ("Pressing d");
		}
		if (Input.GetKey (KeyCode.A)) 
		{
			transform.Rotate(Vector3.down * rotateSpeed);
			Debug.Log("Pressing a");
		}
		if (Input.GetMouseButton (1)) //right mouse boost
		{
			moveSpeed = 20.0f;
		}
		if (!Input.GetMouseButton (1)) //right mouse
		{
			moveSpeed = 5.0f;
		}
		if (Input.GetMouseButton (0)) {}
		*/
	}
}