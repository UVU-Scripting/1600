using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{
	private float inputDirection;					// X value of our moveVector
	private float verticalVelocity;			 // Y value of our moveVector

	private float speed = 5.0f;
	private float gravity = 30.0f;
	private bool secondJumpAvail = false;

	private Vector3 moveVector;
	private Vector3 lastMotion;
	private CharacterController controller;

	private bool facingRight = true;


	// Use this for initialization
	void Start () {
		controller = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update ()
	{
		moveVector = Vector3.zero;
		inputDirection = Input.GetAxis("Horizontal") * speed;


		if(Input.GetKeyDown(KeyCode.A))
		{
			transform.eulerAngles = new Vector3(0,180,0);
		}

		if(Input.GetKeyDown(KeyCode.D))
		{
			transform.eulerAngles = new Vector3(0,0,0);
		}


		if (controller.isGrounded)
		{
			verticalVelocity = 0;

			if(Input.GetKeyDown(KeyCode.Space))
			{
				//Make the player jump!
				verticalVelocity = 10;
				secondJumpAvail = true;
			}
			moveVector.x = inputDirection;
		}
		else
		{
			if(Input.GetKeyDown(KeyCode.Space))
			{
				if(secondJumpAvail)
				{
					verticalVelocity = 10;
					secondJumpAvail = false;
				}

			}
			verticalVelocity -= gravity * Time.deltaTime;
			moveVector.x = lastMotion.x;
		}

		moveVector.y = verticalVelocity;
		//moveVector = new Vector3 (inputDirection,verticalVelocity,0);
		controller.Move(moveVector * Time.deltaTime);
		lastMotion = moveVector;
	}
	void Flip ()
	{
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}
}
