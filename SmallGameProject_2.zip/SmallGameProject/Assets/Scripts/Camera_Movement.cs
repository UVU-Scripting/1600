﻿using UnityEngine;
using System.Collections;

public class Camera_Movement : MonoBehaviour {

	public GameObject Player;
	private Vector3 camera_Offset;
	
	void Start ()
	{
		// Gets the starting offset of the camera from the player
		camera_Offset = transform.position - Player.transform.position;
	}

	// Updates after all other Updates have run
	void LateUpdate ()
	{
		// adds the Camera's starting offset to the current player position to get the new camera position
		transform.position = Player.transform.position + camera_Offset;
	}
}
