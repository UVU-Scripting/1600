﻿using UnityEngine;
using System.Collections;

public class Player_Controls : MonoBehaviour {
	Vector3 origin_Position = new Vector3 (0.0f, -0.5f,0.0f), origin_Scale = new Vector3 (1.0f, 1.0f,1.0f), left = new Vector3(0.0f, 0.0f, -1.0f), right = new Vector3(0.0f, 0.0f, 1.0f);

    const float FIVE = 5.0f, NEGATIVE_FIVE = -5.0f, JUMP_SPEED = 7.0f;
	const string DEATH = "Death", GROUND = "Ground";

	bool touch = false, second_Jump = true;
	
	// Update is called once per frame
	void Update () {
        Jump();
        Forward_Backward_Movement();
	}

    // Forward and Backward Movement
    void Forward_Backward_Movement(){
        // 'A' Moves Backwards
        if (Input.GetKey (KeyCode.A)) {
			GetComponent<Rigidbody> ().velocity = new Vector3 (NEGATIVE_FIVE, gameObject.GetComponent<Rigidbody> ().velocity.y, gameObject.GetComponent<Rigidbody> ().velocity.z);
			transform.rotation = Quaternion.LookRotation(left);
		} 
		else if (Input.GetKeyUp (KeyCode.A))
			GetComponent<Rigidbody> ().velocity = new Vector3(0.0f, GetComponent<Rigidbody> ().velocity.y, 0.0f);
        // 'D' Moves Forwards
        else if (Input.GetKey (KeyCode.D)) {
			GetComponent<Rigidbody> ().velocity = new Vector3 (FIVE, gameObject.GetComponent<Rigidbody> ().velocity.y, gameObject.GetComponent<Rigidbody> ().velocity.z);
			transform.rotation = Quaternion.LookRotation(right);
		}
        else if (Input.GetKeyUp(KeyCode.D))
			GetComponent<Rigidbody>().velocity = new Vector3(0.0f, GetComponent<Rigidbody> ().velocity.y, 0.0f);
    }

    // Jump
    void Jump(){
		// Single Jump
		if (Input.GetKeyDown (KeyCode.Space) && touch == true) 
			GetComponent<Rigidbody>().velocity = new Vector3 (GetComponent<Rigidbody> ().velocity.x, JUMP_SPEED, GetComponent<Rigidbody> ().velocity.z);
		// Double Jump
		else if (Input.GetKeyDown (KeyCode.Space) && touch == false && second_Jump == true) {
			GetComponent<Rigidbody>().velocity = new Vector3 (GetComponent<Rigidbody> ().velocity.x, JUMP_SPEED, GetComponent<Rigidbody> ().velocity.z);
			second_Jump = false;
		}
    }

	// Collision Enter Checker
	void OnCollisionEnter(Collision x) {
		// Check if touching the ground
		if (x.gameObject.tag == GROUND) {
			touch = true;
			second_Jump = true;
		}
		// Check if entering the death zone
		if (x.gameObject.tag == DEATH) {
			transform.localPosition = origin_Position;
			transform.localScale = origin_Scale;
			transform.rotation = Quaternion.identity;
			GetComponent<Rigidbody>().velocity = Vector3.zero;
		}
	}
	
	// Collision Exit Checker
	void OnCollisionExit(Collision x){
		if(x.gameObject.tag == GROUND)
			touch = false;
	}
}