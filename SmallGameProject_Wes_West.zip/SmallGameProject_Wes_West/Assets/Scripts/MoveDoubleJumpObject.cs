﻿using UnityEngine;
using System.Collections;

public class MoveDoubleJumpObject : MonoBehaviour 
{
	public float speed = 7.0f;
	public float jumpSpeed = 7.0f;
	public int maxJump = 2;
	public bool isGrounded = false;
	public int jumpCount = 1;



	// Update is called once per frame
	void Update () 
	{
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		GetComponent<Rigidbody> ().position += move * speed * Time.deltaTime;

		if (Input.GetKeyDown (KeyCode.Space) && (jumpCount < 3 || isGrounded)) 
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
			jumpCount ++;
		}
		if (Input.GetKeyDown(KeyCode.RightArrow))
			transform.forward = new Vector3(0f, 0f, 1f);
		else if (Input.GetKeyDown(KeyCode.LeftArrow))
			transform.forward = new Vector3(0f, 0f, -1f);

			

	}

	void OnCollisionEnter(Collision col)
	{
		if (col.gameObject.tag == "Platform") 
		{
			isGrounded = true;
			jumpCount = 1;
		}

	}

	void OnCollisionExit(Collision col) {
		if (col.gameObject.tag == "Platform") 
		{
			isGrounded = false;
		}
	}



}