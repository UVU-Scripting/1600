﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
	

		public float speed = 5.0f;
		public float jumpSpeed = 6.0f;
		
		void Update ()
		{
			if (Input.GetKey(KeyCode.LeftArrow))
			{
				transform.position += Vector3.left * speed * Time.deltaTime;
			}
			if (Input.GetKey(KeyCode.RightArrow))
			{
				transform.position += Vector3.right * speed * Time.deltaTime;
			}


		/*	if (Input.GetKey(KeyCode.Space))
			{
				transform.position += Vector3.up * speed * Time.deltaTime*2;
			}
		*/	
			if (Input.GetKeyDown (KeyCode.Space)) 
		{
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
		}

	}


	}
