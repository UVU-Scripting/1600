﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour {

    public float speed = 8.0f;
    public float jumpspeed = 7.0f;
	
	// Update is called once per frame
	void Update ()
    {
	//moving an object Horizontally and Vertically
    var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
        transform.position += move * speed * Time.deltaTime;


    //Jumping with a spacebar
    if (Input.GetKeyDown (KeyCode.Space))
        {
            GetComponent<Rigidbody>().velocity += Vector3.up * jumpspeed;
        }
	}
}
