﻿/*using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Text : MonoBehaviour {

	public static int tallyInt;
	Text text;
	
	// Use this for initialization
	void Awake () 
	{
		text = GetComponent<Text> ();
		tallyInt = 0;
	}
	
	// Update is called once per frame
	void Update () 
	{
		text.text = "Tally: " + tallyInt.ToString ();
	}
}*/