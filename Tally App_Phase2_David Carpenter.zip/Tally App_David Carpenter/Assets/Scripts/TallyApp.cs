﻿using UnityEngine;
using System.Collections;

public class TallyApp : MonoBehaviour {

	public static int tallyInt = 0;
	

	void Update ()
{
		if (Input.GetKeyDown (KeyCode.A))
		{
			tallyInt ++;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.S) && (tallyInt > 0))
		{
			tallyInt --;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.R))
		{
			tallyInt = 0;
			print (tallyInt);
		}
	}
}

