﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TallyAppPhaseZwei : MonoBehaviour {

	public static int tallyInt = 0;
	public AudioSource UL_Short_burst_3;
	public AudioSource UL_Short_burst_9;
	public AudioSource UL_Short_burst_15;
	public Button incrementButton;
	public Button decrementButton;
	public Button resetButton;
	public Text tallyCount;

	// Use this for initialization
	void Start () {
	 
		incrementButton.onClick.AddListener (() => Increment ());
		decrementButton.onClick.AddListener (() => Decrement ());
		resetButton.onClick.AddListener (() => Reset ());

	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown(KeyCode.A))
		{
			tallyInt ++;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.S) && (tallyInt > 0)) 
		{
			tallyInt --;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.R)) 
		{
			tallyInt = 0;
			print (tallyInt);
		}
		tallyCount.text = tallyInt.ToString ();
	}
	void Increment()
	{
		tallyInt++;
		UL_Short_burst_3.Play ();
	}
	void Decrement()
	{
	if (tallyInt > 0)
		tallyInt--;
		UL_Short_burst_9.Play ();
	}
	void Reset()
	{
		tallyInt=0;
		UL_Short_burst_15.Play ();
	}
}
