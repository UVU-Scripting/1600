﻿using UnityEngine;
using System.Collections;

public class countUp : MonoBehaviour 
{

	public AudioSource countUpSound;
	
	// Update is called once per frame
	void Update () 
	{
	
		if (Input.GetKeyDown (KeyCode.A)) 
		{

			countUpSound.Play();

		}


	}
}
