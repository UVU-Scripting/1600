﻿using UnityEngine;
using System.Collections;

public class reset : MonoBehaviour 
{
	public AudioSource resetSound;
	
	// Update is called once per frame
	void Update () 
	{
	
		if (Input.GetKeyDown (KeyCode.R)) 
		{
			resetSound.Play();
		}

	}
}
