﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class Tally : MonoBehaviour 

{
	public Button intUp;
	public Button intDown;
	public Button intReset;
	public AudioSource countUpSound;
	public AudioSource countDownSound;
	public AudioSource resetSound;

	public Text countText;
	int tallyInt = 0;

	void Start ()
	{
		intUp.onClick.AddListener (() => IntUp ());
		intDown.onClick.AddListener (() => IntDown ());
		intReset.onClick.AddListener (() => IntReset ());
	}


	// Update is called once per frame
	void Update () 

	{

		SetCountText ();

		if(Input.GetKeyDown(KeyCode.A))
		   {
				tallyInt ++;
				print (tallyInt);
			}
		if(Input.GetKeyDown(KeyCode.S))
		   {

			if (tallyInt > 0) 
			{
				tallyInt --;
				print (tallyInt);
			}
			}
		if (Input.GetKeyDown(KeyCode.R)) 
			{
			tallyInt = 0;
			print (tallyInt);
			}
	}
	void IntUp()
	{
		tallyInt ++;
		countUpSound.Play ();
	}
	void IntDown()
	{
		countDownSound.Play ();
		if(tallyInt > 0)
		tallyInt --;

	}
	void IntReset()
	{
		tallyInt = 0;
		resetSound.Play ();
	}
	void SetCountText()
	{
		countText.text = "Count: "  + tallyInt.ToString ();
	}
}
