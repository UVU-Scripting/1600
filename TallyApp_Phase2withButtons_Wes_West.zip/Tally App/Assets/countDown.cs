﻿using UnityEngine;
using System.Collections;

public class countDown : MonoBehaviour 
{

	public AudioSource countDownSound;
	
	// Update is called once per frame
	void Update () 
	{
	
		if (Input.GetKeyDown (KeyCode.S)) 
		
		{
		
			countDownSound.Play();

		}

	}
}
