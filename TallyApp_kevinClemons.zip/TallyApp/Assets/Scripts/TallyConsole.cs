﻿using UnityEngine;
using System.Collections;

public class TallyConsole : MonoBehaviour {

	private int count;

	// Use this for initialization
	void Start () {
		count = 0;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.A)) {
			DisplayCount(Increment());
		}
		if (Input.GetKeyDown(KeyCode.S) && count > 0) {
			DisplayCount(Decrement ());
		}
		if (Input.GetKeyDown(KeyCode.R)) {
			DisplayCount(Reset());
		}
	}

	int Increment() {
		return ++count;
	}

	int Decrement() {
		return --count;
	}

	int Reset() {
		return (count = 0);
	}

	void DisplayCount(int num) {
		Debug.Log ("Count = " + num);
	}
}
