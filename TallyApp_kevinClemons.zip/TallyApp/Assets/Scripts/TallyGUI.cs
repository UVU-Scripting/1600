﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TallyGUI : MonoBehaviour {

	int tally;
	//Vector2 center;

	public Text countDisplay;
	public Button increment;
	public Button decrement;
	public Button reset;
	public AudioSource incSound;
	public AudioSource decSound;
	public AudioSource resetSound;

	// Use this for initialization
	void Start () {
		tally = 0;
		
		//center = new Vector2(Screen.width / 2, Screen.height / 2);

		// Tell each button what to do when clicked by adding a listener with a lambda function.
		increment.onClick.AddListener(() => Increment());
		decrement.onClick.AddListener(() => Decrement());
		reset.onClick.AddListener(() => Reset());
	}
	
	// Update is called once per frame
	void Update () {
		countDisplay.text = "Current Tally = " + tally;

		if (tally == 0) {
			decrement.interactable = false;
			reset.interactable = false;
		}
	}

	// Functions called when a button is clicked.
	void Increment() {
		incSound.Play();
		tally++;
		decrement.interactable = true;
		reset.interactable = true;
	}
	void Decrement() {
		if (tally > 0) {
			decSound.Play();
			tally--;
		}
	}
	void Reset() {
		resetSound.Play();
		tally = 0;
	}


	/*
	void OnGUI() {
		if (GUI.Button (new Rect (center.x - 80, center.y, 160, 30), "Increment")) {
			tally++;
		}
		if (GUI.Button (new Rect(center.x - 80, center.y + 40, 160, 30), "Decrement") && tally > 0) {
			tally--;
		}
		if (GUI.Button (new Rect(center.x - 80, center.y + 80, 160, 30), "Reset")) {
			tally = 0;
		}
	}
	*/
}
