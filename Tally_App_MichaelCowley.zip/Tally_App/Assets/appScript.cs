﻿using UnityEngine;
using System.Collections;

public class appScript : MonoBehaviour {

	int tallyInt = 0;

	// Use this for initialization
	void Update () 
	{	

	//Key down for incrementing
		if(Input.GetKeyDown(KeyCode.A))
		{
			tallyInt ++;
			Debug.Log(tallyInt);
		}
	
	//Key down for decrementing
		if(Input.GetKeyDown(KeyCode.S))
		{
			if (tallyInt > 0){
			
			tallyInt --;
				Debug.Log(tallyInt);}
		}

	//Key down for reset to 0
		if(Input.GetKeyDown(KeyCode.R))
		{
			tallyInt = 0;
			Debug.Log(tallyInt);
		}

	}
	
}





