﻿using UnityEngine;
using System.Collections;

public class Tally_Controls : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
		Controls ();
	}
	
	void Controls () {
		if (Input.GetKeyUp (KeyCode.A)) {
			Tally_Driver.counter++;
			print(Tally_Driver.counter);
		} else if (Input.GetKeyUp (KeyCode.S) && Tally_Driver.counter > 0) {
			Tally_Driver.counter--;
			print(Tally_Driver.counter);
		} else if (Input.GetKeyUp (KeyCode.R)) {
			Tally_Driver.counter = 0;
			print(Tally_Driver.counter);
		}
	}
}
