﻿using UnityEngine;
using System.Collections;

public class Tally_Driver : MonoBehaviour {

	public static int counter;

	void Start () {
		counter = 0;
	}
}
