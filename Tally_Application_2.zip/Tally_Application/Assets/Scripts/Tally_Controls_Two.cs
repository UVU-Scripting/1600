﻿using UnityEngine;
using System.Collections;

public class Tally_Controls_Two : MonoBehaviour {
	const string increment_Title = "+", reset_Title = "Reset", decrement_Title = "-";
	
	Rect increment_Location = new Rect(Screen.width/2 + 50, Screen.height/2 - 100, 50, 50);
	Rect reset_Location = new Rect(Screen.width/2 - 50, Screen.height/2 - 100, 100, 50);
	Rect decrement_Location = new Rect(Screen.width/2 - 100, Screen.height/2 - 100, 50, 50);
	Rect output_Location = new Rect (Screen.width / 2 - 100, Screen.height / 2 - 25, 200, 100);
	Rect Background_Location = new Rect(0, 0, Screen.width, Screen.height);
	
	public GUISkin The_Style;
	public Texture The_Background;
	
	string output;
	
	void Start() {
		output = Tally_Driver.counter.ToString ();
	}
	
	void OnGUI (){
		GUI.skin = The_Style;

		GUI.DrawTexture(Background_Location, The_Background);

		if (GUI.Button (increment_Location, increment_Title)) {
			Tally_Driver_Two.counter++;
			Tally_Driver_Two.play_ID_Sound = true;
			output = Tally_Driver_Two.counter.ToString ();
		} 
		else if (GUI.Button (reset_Location, reset_Title) && Tally_Driver_Two.counter != 0) {
			Tally_Driver_Two.counter = 0;
			Tally_Driver_Two.play_Reset_Sound = true;
			output = Tally_Driver_Two.counter.ToString ();
		} 
		else if (GUI.Button (decrement_Location, decrement_Title) && Tally_Driver_Two.counter > 0) {
			Tally_Driver_Two.counter--;
			Tally_Driver_Two.play_ID_Sound = true;
			output = Tally_Driver_Two.counter.ToString ();
		}
		
		GUI.Label (output_Location, output);
	}
}
