﻿using UnityEngine;
using System.Collections;

public class Tally_Driver_Two : MonoBehaviour {

	public static int counter;
	public static bool play_ID_Sound;
	public static bool play_Reset_Sound;
	
	public AudioClip iD_Sound, reset_Sound;
	private AudioSource source;
	
	const float F_ONE = 1.0f;
	
	void Start () {
		source = GetComponent<AudioSource>();
		play_ID_Sound = false;
		play_Reset_Sound = false;
		counter = 0;
	}
	
	void Update() {
		Sound_Play ();
	}
	
	void Sound_Play(){
		if (play_ID_Sound == true) {
			source.PlayOneShot(iD_Sound, F_ONE);
			play_ID_Sound = false;
		}
		else if (play_Reset_Sound == true) {
			source.PlayOneShot(reset_Sound, F_ONE);
			play_Reset_Sound = false;
		}
		
	}
}
