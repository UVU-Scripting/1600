﻿using UnityEngine;
using System.Collections;

public class GameCubeMovement : MonoBehaviour {

	public AudioSource jumpingSound;
	public float maxSpeed = 7f;
	public float jumpSpeed = 5f;

	private CharacterController controller;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame


	void Update(){

		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		transform.position += move * maxSpeed * Time.deltaTime;

		if (Input.GetKeyDown (KeyCode.Space)) {
				GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
				jumpingSound.Play ();
			}
		}


}
