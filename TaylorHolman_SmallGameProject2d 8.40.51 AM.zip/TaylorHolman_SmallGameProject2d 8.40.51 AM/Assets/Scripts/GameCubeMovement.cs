﻿using UnityEngine;
using System.Collections;

public class GameCubeMovement : MonoBehaviour {

	public AudioSource runningSound;
	public AudioSource jumpingSound;
	public float maxSpeed = 10f;
	bool facingRight = true;
	public float jumpForce = 200f;
	public int jumpCount = 1;
	public float maxJump = 2.0f;
	bool grounded = false;
	public Transform groundCheck;
	float groundRadius = 0.2f;
	public LayerMask whatIsGround;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		grounded = Physics2D.OverlapCircle (groundCheck.position, groundRadius, whatIsGround);


		float move = Input.GetAxis ("Horizontal");


		GetComponent<Rigidbody2D>().velocity = new Vector2 (move * maxSpeed, GetComponent<Rigidbody2D>().velocity.y);

		if (move > 0 && !facingRight) {
			Flip ();
		} else if (move < 0 && facingRight) {
			Flip ();
		}
	}

	void Update(){
		if (Input.GetKeyDown (KeyCode.Space) && jumpCount <= 1) {
			GetComponent<Rigidbody2D> ().AddForce (new Vector2 (0, jumpForce));
			jumpCount ++;
		}
		if (grounded) {
			jumpCount = 1;
		}


	}

	void Flip(){
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}
}
