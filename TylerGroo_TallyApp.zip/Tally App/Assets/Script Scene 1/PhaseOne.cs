﻿using UnityEngine;
using System.Collections;

public class PhaseOne : MonoBehaviour {

	int tallyInt = 0;
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.A)) 
		{
			tallyInt ++;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.S))
		if (tallyInt>0)
		{
			tallyInt --;
			print (tallyInt);
		}
		if (Input.GetKeyDown (KeyCode.R))
		{
			tallyInt = 0;
			print (tallyInt);
		}
	}
}
