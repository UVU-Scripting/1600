﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class scriptTexttest : MonoBehaviour 
{
	public Text bubbleText;
    public GameObject bubble;
	
	void Start ()
	{
		bubbleText.text = "☺☻♥♦♣♠•◘○◙♂♀♪♫☼►◄↕‼▬↨↑↓→←\n" + "∟↔▲▼!#$%&'()*+,-./0123456789:;<=>?\n"
			+ "@ABCDEFGHIJKLMNOPQRSTUVWXYZ\n`abcdefghijklmnopqrstuvwxyz\nîìÄÅÉæÆôöòûùÿÖÜ¢£¥ƒáíóúñÑªº¿¬½¼¡«\n "
				+ "»░▒▓│┤╣║╗┐└┴┬├─┼╚╔╩╦╣║╗•§©®¶" + "\nThanks for using fonts from JazzCreates2015©.";
	}
}