﻿using UnityEngine;
using System.Collections;

public class TestAddition : MonoBehaviour {
	public int myInt = 0; 
	public GUIText TallyCount;
	public void ClickTest ()

	{
		myInt++;
		print (myInt);
	}
	public void ClickTest2 ()
	{
		if (myInt > 0)
		{
			myInt--;
			print (myInt);
		}
	}
	public void ClickTest3 ()
	{
		myInt = 0;
		print (myInt);
	}
	
	void updateTally()
	{
		TallyCount.text = ""+myInt;
	}
}
