﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DonutProperties : MonoBehaviour {

	public Text text;
	public Text text2;
	public Text text3;
	public Text text4;

	public  float x;
	public  float tax;
	public  float delivery;
	public  float TotalCost;

	public float total;

	public Slots [] boxSlots;
	
	public void Start () {
		x = 0;
		tax = 0;
		delivery = 0;
		TotalCost = 0;

		total = 0;

		text = text.GetComponent<Text> ();
		text2 = text2.GetComponent<Text> ();
		text3 = text3.GetComponent<Text> ();
		text4 = text4.GetComponent<Text> ();
	
	}

	public void Calculate (float x)
	{
		tax = x * 0.07f;
		delivery = 3.5f;
		TotalCost = x + tax + delivery;
	}

 public void  Update(){
		total = 0;
		foreach (Slots donut in boxSlots) {
			if (donut.heldDonut != null){
			total += donut.heldDonut.price;
			}
		}
		Calculate (total);

		text.text = "Subtotal: " + total.ToString ("C2");
		text2.text = "Tax: " + tax.ToString ("C2");
		text3.text = "Delivery: " + delivery.ToString ("C2");
		text4.text = "Total: " + TotalCost.ToString ("C2");
		
	}
}
	
