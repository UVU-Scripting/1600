﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class DragHandeler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {

	public static GameObject itemBeingDragged;
	Vector3 startPosition;
	Transform startParent;


	#region IBeginDragHandler implementation

	public void OnBeginDrag (PointerEventData eventData)
	{

		itemBeingDragged = Instantiate<GameObject>(gameObject);
		itemBeingDragged.transform.SetParent(gameObject.transform.parent);

		startPosition = transform.position;
		startParent = transform.parent;
		GetComponent<CanvasGroup> ().blocksRaycasts = false;
	}

	#endregion

	#region IDragHandler implementation

	public void OnDrag (PointerEventData eventData)
	{
		itemBeingDragged.transform.position = Input.mousePosition;
	}

	#endregion

	#region IEndDragHandler implementation

	public void OnEndDrag (PointerEventData eventData)
	{
		GetComponent<CanvasGroup> ().blocksRaycasts = true;
		if (itemBeingDragged.transform.parent == startParent) {
			itemBeingDragged.transform.position = startPosition;
		}
	
		itemBeingDragged = null;
	}

	#endregion



}

