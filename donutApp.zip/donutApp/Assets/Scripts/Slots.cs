﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class Slots : MonoBehaviour, IDropHandler{

	public Donuts heldDonut;
	public GameObject item {
		get {
			if (transform.childCount > 0) {
				return transform.GetChild (0).gameObject;
			}
			return null;
		}
	}
	public GameObject donut;

	public void Start(){
		donut = item;
	}

	#region IDropHandler implementation

	public void OnDrop (PointerEventData eventData)
	{
		if (!item) {
			DragHandeler.itemBeingDragged.transform.SetParent (transform);
			heldDonut=DragHandeler.itemBeingDragged.GetComponent<Donuts>();


		}

	}

	#endregion
}
