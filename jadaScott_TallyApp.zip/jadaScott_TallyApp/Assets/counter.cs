﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;



public class counter : MonoBehaviour {

	int tally = 0;
	public AudioSource _AudioSource;
	public AudioClip increment;
	public AudioClip decrement;
	public AudioClip reset;
	Text text;

	void Awake ()
	{
		text = GetComponent <Text> ();
	}

	void Update ()
	{
		text.text = "Current Count: " + tally;
	}


	void OnGUI() {

		if (GUI.Button (new Rect (100, 425, 100, 50), "Increment")) 
		{
			++tally;
			print (tally);
			_AudioSource.clip = increment;
			_AudioSource.Play ();
		}

			if (GUI.Button (new Rect (300, 425, 100, 50), "Decrement")) 
		{
			--tally; 
			print (tally);
			_AudioSource.clip = decrement;
			_AudioSource.Play ();
		}


		if (GUI.Button (new Rect (500, 425, 100, 50), "Reset")) 
		{
			tally = 0;
			print (tally);
			_AudioSource.clip = reset;
			_AudioSource.Play ();  
		}		  

   }
}

