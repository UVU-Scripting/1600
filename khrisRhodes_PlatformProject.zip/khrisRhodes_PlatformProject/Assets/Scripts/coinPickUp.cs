﻿using UnityEngine;
using System.Collections;

public class coinPickUp : MonoBehaviour 
{	
	public Transform coinEffect;

	int coinValue = 1;

	// Update is called once per frame
	void OnTriggerEnter (Collider other) 
	{
		if (other.tag == "Player")
		{
			gameMaster.currentScore += coinValue;
			print("number of coins picked up " + gameMaster.currentScore);
			Instantiate(coinEffect, transform.position, transform.rotation);
			Destroy(gameObject);
		}
	}
}
