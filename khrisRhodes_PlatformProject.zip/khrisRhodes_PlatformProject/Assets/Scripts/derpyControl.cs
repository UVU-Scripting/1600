﻿using UnityEngine;
using System.Collections;

public class derpyControl : MonoBehaviour 
{
	public Rigidbody rb;
	public float jumpHeight = 5;
	public float walkRight = 5;
	public float walkLeft = -5;

	//private float faceForward = 0;
	//private float faceBackward = 179.999f;
	private int jumpCount = 2;
	private bool inAir = false;

	// Use this for initialization
	void Start () 
	{
		rb = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		// while D is held down, player will move to the right.
		if (Input.GetKey (KeyCode.D)) 
		{
			transform.Translate(walkRight * Time.deltaTime, 0, 0);
			/*if (transform.rotation.y == faceBackward)
			{
				transform.Rotate(0, 0, 0);
			}*/
		}

		// while A is held down, player will move to the left.
		if (Input.GetKey (KeyCode.A))
		{
			transform.Translate(walkLeft * Time.deltaTime, 0, 0);
			/*if (transform.rotation.y <= faceForward)
			{
				transform.Rotate(0, 180, 0);
			}*/
		}

		// if spacebar is down and inAir bool = false, player will jump and lose a jump count.
		if (Input.GetKeyDown (KeyCode.Space) && inAir == false) 
		{
			rb.velocity = new Vector3(0, jumpHeight, 0);
			jumpCount--;
		}
		// if jump count = zero, inair bool = true.
		if (jumpCount == 0) 
		{
			inAir = true;
		}
	}
	// if player collides with "floor", inAir = false and jump count reset to two.
	void OnCollisionEnter (Collision other)
	{
		if (other.collider.name == "floor") 
		{
			inAir = false;
			jumpCount = 2;
		}
	}
}
