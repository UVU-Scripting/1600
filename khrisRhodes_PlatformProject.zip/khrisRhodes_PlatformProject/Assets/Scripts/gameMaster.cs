﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class gameMaster : MonoBehaviour 
{
	public Text scoreboard;
	public static int currentScore = 0;
	public int score = 0;

	// Update is called once per frame
	void Update () 
	{
		score = currentScore;
		scoreboard.text = "score " + currentScore;
		//tallyCount.text = "Tally count = " + tallyNum;
	}
}
