﻿using UnityEngine;
using System.Collections;

public class Grocerylist_vincent : MonoBehaviour {

	// Use this for initialization
	void Start () {

		//tell user use of project
		print ("This is my Grocery list");
		//creat array for individual grocery list

		string [] strings = new string [6];

		strings[0] = "Milk";
		strings[1] = "Navel Oranges";
		strings[2] = "Coco-puffs Cereal";
		strings[3] = "Can of Black Beans";
		strings[4] = "Donuts";
		strings[5] = "Butter";
		
		// create variable for each string
		 
		foreach(string item in strings)
		{
			int items = 6;
			print (item);
			items--;
	}
	

}
}
