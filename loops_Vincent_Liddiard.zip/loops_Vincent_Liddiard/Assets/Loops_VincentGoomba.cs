﻿using UnityEngine;
using System.Collections;

public class Loops_VincentGoomba : MonoBehaviour {

	// Use this for initialization
	void Start () {

		// initialize variable
		int goomba = 12;
		// create while loop
		while (goomba > 1)
		{
			//decrement goomba
			goomba--;
			//output result
			Debug.Log("One Goomba has been smashed! Goomba count "+ goomba);



				}
		//print out end statement of while loop
		print ("All the Goombas are smashed...Go Mario!");
	
	}
	

}
