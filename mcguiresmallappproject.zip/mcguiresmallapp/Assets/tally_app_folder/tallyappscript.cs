﻿using UnityEngine;
using System.Collections;

public class tallyappscript : MonoBehaviour 
{
	int tallyInt = 0;
	
	// Update is called once per frame
	void Update () 
	
	{
	
		
		if (Input.GetKeyDown
			(KeyCode.A))

			{
			
			tallyInt ++;
			print(tallyInt);
			
			}
				
				if (Input.GetKeyDown
					(KeyCode.S) && tallyInt > 0)
					
					{
						tallyInt --;
				print(tallyInt);
				
					}
				


	}

}

	



