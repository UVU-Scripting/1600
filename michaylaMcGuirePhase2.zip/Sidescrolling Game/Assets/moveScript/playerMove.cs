﻿using UnityEngine;
using System.Collections;

public class playerMove : MonoBehaviour {
	public int speed = 10;
	public int jumpSpeed = 3;
	public int maxJump = 2;
	bool isGrounded = true;
	public int jumpCount = 1;


	// moving the player horizontally and vertically
	void Update () 
{
		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);
		GetComponent<Rigidbody> ().position += move * speed * Time.deltaTime;

		//making the player jump with the spacebar

		if (Input.GetKeyDown (KeyCode.Space) && maxJump < 3) {
			GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed * maxJump;
			jumpCount ++;
		}
		if (jumpCount > maxJump || isGrounded == false) {
			jumpSpeed = 0;
		}

	}		
		void OnCollisionEnter(Collision col)
	{
		if(col.gameObject.tag == "Floor1")
		{
			jumpCount = 1;
			jumpSpeed = 3;
			
		}

	}

}




















