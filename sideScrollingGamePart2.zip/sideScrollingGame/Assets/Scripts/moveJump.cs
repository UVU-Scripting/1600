﻿using UnityEngine;
using System.Collections;

public class moveJump : MonoBehaviour {

	public float speed = 8.0f;

	public float jumpSpeed = 7.0f;
	public float maxJump = 2.0f;

	private bool grounded = true;
	public int jumpCount = 1;

	bool facingRight = true;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{


		var move = new Vector3 (Input.GetAxis ("Horizontal"), Input.GetAxis ("Vertical"), 0);

		transform.position += move * speed * Time.deltaTime;


		if (Input.GetKeyDown (KeyCode.A)) {
			transform.eulerAngles = new Vector2 (0, 180);
		}
		if (Input.GetKeyDown (KeyCode.D)) {
			transform.eulerAngles = new Vector2 (0, 0);
		}

		

			if (Input.GetKeyDown (KeyCode.Space)) {
				GetComponent<Rigidbody> ().velocity += Vector3.up * jumpSpeed;
				jumpCount ++;
			}
			if (jumpCount > maxJump || grounded == false) {
				jumpSpeed = 7.0f;
			}
			if (jumpCount > maxJump && grounded == true) {
				jumpSpeed = 0.0f;
				jumpCount = 1;
			}


		}
	void Flip()

	{
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

	

	void OnCollisionEnter(Collision col)
	{
		if (col.gameObject.tag == "Floor01") {
			jumpCount = 1;
			jumpSpeed = 7;
		}
	}
}
