﻿using UnityEngine;
using System.Collections;

public class SmallProjectPhase1 : MonoBehaviour {

	int tally = 0;

	void Update () {



		if (Input.GetKeyDown (KeyCode.A))
		{
			++tally;
			Debug.Log (tally);
		}

		if (Input.GetKeyDown (KeyCode.S)) {
			if (tally > 0) 
			{
				--tally;
				Debug.Log (tally);
			}
		}


		if (Input.GetKeyDown (KeyCode.R)) 
		{
			tally = 0;
			Debug.Log (tally);
		}


	
	}
}
