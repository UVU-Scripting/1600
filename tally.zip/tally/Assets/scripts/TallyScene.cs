﻿using UnityEngine;
using System.Collections;

public class TallyScene : MonoBehaviour 
{
	int tallyint = 0;

	// Update is called once per frame
	void Update () 
	{
	if (Input.GetKeyDown (KeyCode.A))
		{
			tallyint++;
			print (tallyint);
	}
		if (Input.GetKeyDown (KeyCode.S))
		{
			if (tallyint > 0)
			{
				tallyint--;
				print (tallyint);
			}
			else
			{
				print (tallyint);
			}
		}
		if (Input.GetKeyDown (KeyCode.R))
		{
			tallyint = 0;
				print (tallyint);
		}
	}
}
