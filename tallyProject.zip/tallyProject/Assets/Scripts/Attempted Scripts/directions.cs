﻿using UnityEngine;
using System.Collections;

public class directions : MonoBehaviour {
	public GameObject numberTotal;
	public updateValue changeValueuB;
	void Start () {
		numberTotal = GameObject.Find("numberTotal");
		changeValueuB = numberTotal.GetComponent<updateValue> ();
		changeValueuB.count++;
	}
}
