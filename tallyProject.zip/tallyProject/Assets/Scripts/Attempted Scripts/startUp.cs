﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class startUp: MonoBehaviour {

	void Start () {

	}
}
