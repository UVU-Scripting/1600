﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class updateValue : MonoBehaviour {
	public Text countDisp;
	public int count = 0;
	public void Start () {
		print ("Button Layout: A=+1, S=-1, R=Reset.");
		countDisp.text = "" + count;
	}
	public void Update () {
		if (Input.GetKeyDown(KeyCode.A)) {
			count++;
			print (count);
			countDisp.text = "" + count;}
		if ((Input.GetKeyDown(KeyCode.S)) && (count>0)) {
			count--;
			print (count);
			countDisp.text = "" + count;}
		if (Input.GetKeyDown(KeyCode.R) && (count!=0)) {
			count = 0;
			print (count);
			countDisp.text = "" + count;}
	}
}
