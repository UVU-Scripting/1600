﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class finalCountdown : MonoBehaviour {
	int numberTotal;
	public Text displayTotal;
	public Button valueUp;
	public Button valueDown;
	public Button valueReset;
	public AudioSource startUp;
	public AudioSource valueUpAudio;
	public AudioSource valueDownAudio;
	public AudioSource valueResetAudio;
	void Start () {
		startUp.Play ();
		valueUp.onClick.AddListener (() => ValueUp ());
		valueDown.onClick.AddListener (() => ValueDown ());
		valueReset.onClick.AddListener (() => ValueReset ());
	}
	void Update () {
		if (numberTotal == 0) {
			valueDown.interactable = false;
			valueReset.interactable = false;
		}
		else if (numberTotal <= 1) {
			valueDown.interactable = true;
			valueReset.interactable = true;
		}
		displayTotal.text = "" + numberTotal;
	}
	void ValueUp () {
		numberTotal++;
		valueUpAudio.Play ();
	}
	void ValueDown () {
		numberTotal--;
		valueDownAudio.Play ();
	}
	void ValueReset () {
		numberTotal=0;
		valueResetAudio.Play ();
	}

}
