﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DragHandler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
	public static GameObject itemBeingDragged;
	Vector3 startPosition;
	Transform startParent;

	public float donutPrice;


	#region IBeginDragHandler implementation
	public void OnBeginDrag (PointerEventData eventData)
	{
		itemBeingDragged = gameObject;
		startPosition = transform.position;
		startParent = transform.parent;
		GetComponent<CanvasGroup> ().blocksRaycasts = false;
	}
	#endregion

	#region IDragHandler implementation

	public void OnDrag (PointerEventData eventData)
	{
		transform.position = Input.mousePosition;
	}

	#endregion

	#region IEndDragHandler implementation

	public void OnEndDrag (PointerEventData eventData)
	{
		itemBeingDragged = null;
		GetComponent<CanvasGroup> ().blocksRaycasts = true;
		if (transform.parent != startParent) {
			transform.position = startPosition;
		}
		calculateSubtotal ();
		calculateTax ();
		calculateTotal ();

	}

	#endregion

	void calculateSubtotal(){
		Pricing.subtotal = Pricing.subtotal + donutPrice;
		//subtotalText.text = subtotal.ToString ();
		
	}

	void calculateTax(){
		float salesTaxPercent = 0.06f;
		Pricing.taxes = Pricing.subtotal * salesTaxPercent;
		//taxesText.text = taxes.ToString ();
	}
	
		
	void calculateTotal(){
		Pricing.total = Pricing.subtotal + Pricing.taxes + Pricing.deliveryFee;
		//totalText.text = total.ToString ();
	}

}
