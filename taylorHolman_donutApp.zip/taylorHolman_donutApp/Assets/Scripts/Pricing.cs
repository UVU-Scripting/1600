﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Pricing : MonoBehaviour {
	public static float subtotal = 0;
	public static float taxes = 0;
	public static float deliveryFee = 0.00f;
	public static float total = 0;
	public float donutPrice;
	public Text subtotalText;
	public Text taxesText;
	public Text deliveryFeeText;
	public Text totalText;

	void Update(){
		subtotalText.text = subtotal.ToString ();
		taxesText.text = taxes.ToString ();
		deliveryFeeText.text = deliveryFee.ToString ();
		totalText.text = total.ToString ();
	}




	public void calculateDeliveryFee(){
		deliveryFee = 2.00f;
	}

	public void pickUpFee(){
		deliveryFee = 0.00f;
	}
}
