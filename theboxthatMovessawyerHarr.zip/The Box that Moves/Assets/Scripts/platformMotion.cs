﻿using UnityEngine;
using System.Collections;

public class platformMotion : MonoBehaviour {
	public bool onoffToggle=true;
	private bool valueB = true;
	public int counter = 120;
	private int count = 0;
	void Start () {
	
	}
	void Update () {
	if ((onoffToggle == true) && (count<counter) && (valueB==true)) {
			transform.Translate (new Vector3 (-.05f, 0, 0));
			count++;
		}
		if (count == counter) {
			valueB=false;
		}
		if ((onoffToggle == true) && (valueB == false)) {
			transform.Translate (new Vector3 (.05f, 0, 0));
			count--;
		}
		if (count == 0) {
			valueB = true;
		}
	}
}
