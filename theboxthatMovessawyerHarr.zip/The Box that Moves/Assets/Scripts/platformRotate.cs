﻿using UnityEngine;
using System.Collections;

public class platformRotate : MonoBehaviour {
	public bool onoffToggle=true;
	private bool valueB = true;
	public int counter = 120;
	private int count = 0;
	void Start () {
		
	}
	void Update () {
		if ((onoffToggle == true) && (count<counter) && (valueB==true)) {
			transform.Rotate (new Vector3 (0, 0, -.5f));
			count++;
		}
		if (count == counter) {
			valueB=false;
		}
		if ((onoffToggle == true) && (valueB == false)) {
			transform.Rotate (new Vector3 (0, 0, .5f));
			count--;
		}
		if (count == -60) {
			valueB = true;
		}
	}
}
