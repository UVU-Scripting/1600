﻿using UnityEngine;
using System.Collections;

public class playerScript : MonoBehaviour {
	bool objectGrounded;
	GameObject groundedOn;
	int multiJump = 2;
	Rigidbody2D myRigidBody;
	public int rotationSpeed = 5;
	public float motionSpeed = .1f;
	public int jumpForce = 300;
	public AudioSource jumpAudio;
	bool facingRight = true;
	void Start () {
		myRigidBody = GetComponent<Rigidbody2D> ();
	}
	void Update () {
		if (Input.GetKey (KeyCode.D)) {
			transform.Translate (new Vector3 (motionSpeed, 0, 0));
			if (facingRight == false) {
				facingRight=true;
				Flip ();
			}
		}
		if (Input.GetKey (KeyCode.A)) {
			transform.Translate (new Vector3 (-motionSpeed, 0, 0));
			if (facingRight == true) {
				facingRight = false;
				Flip ();
			}
		}

		if (Input.GetKey (KeyCode.E)) {
			transform.Rotate (0, 0, -rotationSpeed);
		}
		if (Input.GetKey (KeyCode.Q)) {
			transform.Rotate (0, 0, rotationSpeed);
		}
		if (Input.GetKeyDown (KeyCode.LeftShift)) {
			motionSpeed=motionSpeed*2;
			jumpForce=jumpForce*2;
			rotationSpeed=rotationSpeed*2;
		}
		if (Input.GetKeyUp (KeyCode.LeftShift)) {
			motionSpeed=motionSpeed/2;
			jumpForce=jumpForce/2;
			rotationSpeed=rotationSpeed/2;
		}
		if ((Input.GetKeyDown (KeyCode.Space)) && (objectGrounded==true || multiJump > 0)) {
			myRigidBody.AddForce (new Vector3(0, jumpForce, 0));
			multiJump--;
			jumpAudio.Play();
		}
	}
	void OnCollisionEnter2D(Collision2D collObject) {
		foreach (ContactPoint2D contact in collObject.contacts) {
			if (contact.normal.y > 0) {
				objectGrounded = true;
				groundedOn = collObject.gameObject;
				multiJump = 2;
				break;
			}
		}
	}
	void OnCollisionExit2D(Collision2D collObject) {
		if (collObject.gameObject == groundedOn) {
			groundedOn = null;
			objectGrounded = false;
		}
	}
	void Flip(){
		Vector3 charScale = transform.localScale;
		charScale.x *= -1;
		transform.localScale = charScale;
	}
}
