﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class Clicked : MonoBehaviour, IPointerClickHandler {
	public FinalTotal endTotal;
	public float deliveryCharge; 
	public void OnPointerClick (PointerEventData eventData)
	{


	}


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
