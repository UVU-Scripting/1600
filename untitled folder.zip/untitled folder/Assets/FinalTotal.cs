﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;
public class FinalTotal : MonoBehaviour {
	public Text endTotal;
	public List<DragHanddler> donuts;
	public Button myButton = null;
	public Text deliveryTotal;

	Clicked newClick;
	void Start()
	{
		endTotal.text = "";


	;
	}
	public void Update () {


			}


		public void clickmyButton (){
		Pricing.deliverycharge = 2.99f;
				 
		Pricing.atLast = Pricing.atLast + Pricing.deliverycharge;
				Debug.Log ("You have clicked the button");

		Debug.Log (Pricing.atLast);
		endTotal.text = "Final Total: " + Pricing.atLast;

			}
	public void clickPickUpButton (){
		Pricing.deliverycharge = 0f;
		
		Pricing.atLast += Pricing.deliverycharge;
		Debug.Log ("You have clicked the button");
		
		Debug.Log (Pricing.atLast);
		endTotal.text = "Final Total: " + Pricing.atLast;
		
	}

		public void calculateTotal(){
		//float deliveryCharge = 2.99f;


		foreach (DragHanddler donut in donuts) {
			if (donut != null ) {
				if (myButton != null)
					//clicked = false;
					Pricing.atLast = donut.finalTotal;
				
				//	Debug.Log (atLast);
				Mathf.Round (Pricing.atLast);
				endTotal.text = "Final Total: " + Pricing.atLast;
				//Debug.Log (atLast);
				
			}
			//deliverMeDonuts = atLast;
			
		}

	}

	}
		







