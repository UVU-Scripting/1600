﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class Item : MonoBehaviour, IDropHandler{
	//donutbox row 1
	public Text text;
	public GameObject[] allDonuts;
	float Donuttotal = 0;
	float radius;
	public static float donutPrice = .99f;
	//float total = 10;


	public void OnDrop(PointerEventData eventData){
			

			if (gameObject.tag == "Inventory" || gameObject.tag == "Inventory1") {
			if (DragHanddler.itemBeingDragged == true) {
				//if (CollisionDetectionMode(allDonuts))
			

				Donuttotal = Donuttotal + donutPrice;
				Debug.Log (Donuttotal);

				text.text = "total = " + Donuttotal.ToString();
			}

		
	}
				}
			}

		
	


