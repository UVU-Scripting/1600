﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class Taxes : MonoBehaviour {

	public List<DragHanddler> donuts;
	public Text taxPrice;
	public float addTaxes;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		float addTaxes = 0;
		foreach (DragHanddler donut in donuts) {
			if (donut != null) {
				addTaxes += donut.taxPrices + donut.donutPrice;

				Mathf.Round(addTaxes);
				
			}
			

			Pricing.atLast = addTaxes;
			taxPrice.text = "Taxes: " + addTaxes.ToString ();

		}
		

	}
}
