﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class TextElement : MonoBehaviour {
	public List<DragHanddler> donuts;
	public Text totalText;
	public Text finalPrice;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		float total = 0;
		foreach (DragHanddler donut in donuts) {
			if (donut != null) {
				total += donut.donutPrice;

				Mathf.Round(total);
			}

			//Pricing.atLast = total;

		totalText.text = "Total: " + total.ToString ();

		
	}


}
}