﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class dropscript : MonoBehaviour, IDropHandler {
	public Text totaltext;
	public TextElement textElement;
	public Taxes TaxText;
	public Text taxPrice;
	public FinalTotal finaltotal;
	public Text endTotal;
	//public FinalTotal finaltotaltwo;

	//public Text toDeliver;


	void Start() {
		textElement = totaltext.GetComponent<TextElement> ();
		TaxText = taxPrice.GetComponent<Taxes> () ;
		finaltotal  = endTotal.GetComponent<FinalTotal>();
		//finaltotaltwo = toDeliver.GetComponent<FinalTotal>();
	}

		public  GameObject item {
		get {
			if(transform.childCount>0){
				return transform.GetChild (0).gameObject;
			}
			return null;
		}


	}
	

	public void OnDrop (PointerEventData eventData)
	{
			if (!item) {
				DragHanddler.itemBeingDragged.transform.SetParent (transform);
			//finaltotaltwo.donuts.Add (DragHanddler.itemBeingDragged.GetComponent<DragHanddler>());
			finaltotal.donuts.Add (DragHanddler.itemBeingDragged.GetComponent<DragHanddler>());
			textElement.donuts.Add( DragHanddler.itemBeingDragged.GetComponent<DragHanddler>());
			TaxText.donuts.Add (DragHanddler.itemBeingDragged.GetComponent<DragHanddler>());
				if (gameObject.tag == "Background" || gameObject.tag == "DonutBox" || gameObject.tag == "Finish") {
					DestroyImmediate (DragHanddler.itemBeingDragged);
					//Debug.Log(DragHanddler.itemBeingDragged +"has been destroyed");
				}

				

					


		
			
			
			}
		}
	}
	
	











