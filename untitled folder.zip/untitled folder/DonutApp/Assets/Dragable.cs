﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
public class Dragable : MonoBehaviour, IDragHandler, IDropHandler, IBeginDragHandler {


	void OnBeginDrag(PointerEventData eventData)
	{

	}



}
